summon armor_stand ~ ~ ~ {Tags:["fokus.summoner"],Invisible:true}
execute as @e[type=armor_stand,tag=fokus.summoner] at @s run function fokus:spawn_mob