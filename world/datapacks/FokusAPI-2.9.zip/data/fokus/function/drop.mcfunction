execute at @s positioned ^ ^ ^3 run function fokus:nxf/j3j3t3s
data modify entity @e[type=item,tag=dropped,limit=1] Item set from entity @s SelectedItem
data modify entity @e[type=item,tag=dropped,limit=1] Glowing set value true
scoreboard players set $lh83BG lArOQlvbt 0
execute if score $lh83BG lArOQlvbt matches 0 run function fokus:nxf/_ignored_o9aknpyh
execute if score $lh83BG lArOQlvbt matches 0 run function fokus:nxf/_ignored_owtuvm1
scoreboard players set $lh83BG lArOQlvbt 0
tag @e[type=item,tag=dropped] remove dropped