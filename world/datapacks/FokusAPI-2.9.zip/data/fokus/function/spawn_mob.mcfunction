scoreboard players operation @s fokus.scores = @p fokus.scores
spreadplayers ~5 ~5 10 140 false @s
execute at @s unless entity @p[distance=..8] run function fokus:nxf/5lcgwfr7ntr
kill @s