tag @s add fkapi.waittg
scoreboard players operation @s fk.et.ptm = $fokusapi fk.ttm
schedule function fokus:nxf/wy7o7 1.5s append