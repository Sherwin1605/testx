scoreboard objectives add fk.ttm dummy
function fokus:nxf/81t0p1jnb