effect give @s invisibility 10 1 true
tag @s add cspawn.rd
summon armor_stand ~ ~ ~ {Tags:["fokus.summoner"],Invisible:true}
execute as @e[type=armor_stand,tag=fokus.summoner] at @s run function fokus:nxf/nue9yxkl