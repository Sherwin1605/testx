gamerule projectilesCanBreakBlocks
scoreboard players set MinecraftVersion VersionInfo 9
function fokus:vd/cores/1.20.5