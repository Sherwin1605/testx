execute if entity @e[type=warden]
scoreboard players set MinecraftVersion VersionInfo 6
function fokus:vd/cores/1.20