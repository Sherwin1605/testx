give @s music_disc_otherside
scoreboard players set MinecraftVersion VersionInfo 5
function fokus:vd/cores/1.19