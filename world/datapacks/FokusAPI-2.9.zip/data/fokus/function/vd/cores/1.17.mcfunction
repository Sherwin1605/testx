execute if entity @e[type=axolotl]
scoreboard players set MinecraftVersion VersionInfo 4
function fokus:vd/cores/1.18