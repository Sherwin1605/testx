execute if entity @e[type=minecraft:creaking]
scoreboard players set MinecraftVersion VersionInfo 14