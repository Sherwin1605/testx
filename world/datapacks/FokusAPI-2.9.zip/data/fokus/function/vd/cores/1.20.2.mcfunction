random value 0..1
scoreboard players set MinecraftVersion VersionInfo 8
function fokus:vd/cores/1.20.3