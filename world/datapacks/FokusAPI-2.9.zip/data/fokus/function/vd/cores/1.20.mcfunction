execute if entity @e[type=sniffer]
scoreboard players set MinecraftVersion VersionInfo 7
function fokus:vd/cores/1.20.2