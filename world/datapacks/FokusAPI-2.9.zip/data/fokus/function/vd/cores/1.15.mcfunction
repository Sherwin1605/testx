execute if entity @e[type=bee]
scoreboard players set MinecraftVersion VersionInfo 2
function fokus:vd/cores/1.16