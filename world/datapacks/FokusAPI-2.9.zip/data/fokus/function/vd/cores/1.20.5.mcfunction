# gamerule spawnChunkRadius
# Force pass
scoreboard players set MinecraftVersion VersionInfo 10
function fokus:vd/cores/1.21