give @s blue_bundle
scoreboard players set MinecraftVersion VersionInfo 12
function fokus:vd/cores/1.21.4