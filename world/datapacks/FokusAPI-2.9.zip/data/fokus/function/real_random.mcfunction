execute if predicate fokus:real_random_pr run scoreboard players operation $fk.oput fokus.rrv += #-2147483648 fokus.rrv
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 1073741824
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 536870912
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 268435456
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 134217728
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 67108864
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 33554432
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 16777216
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 8388608
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 4194304
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 2097152
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 1048576
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 524288
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 262144
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 131072
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 65536
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 32768
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 16384
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 8192
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 4096
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 2048
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 1024
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 512
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 256
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 128
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 64
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 32
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 16
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 8
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 4
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 2
execute if predicate fokus:real_random_pr run scoreboard players add $fk.oput fokus.rrv 1
scoreboard players operation $fk.uinput fokus.rrv -= $fk.linput fokus.rrv
execute store result score $fk.oput fokus.rrv run scoreboard players operation $fk.oput fokus.rrv %= $fk.uinput fokus.rrv
scoreboard players operation $fk.oput fokus.rrv += $fk.linput fokus.rrv
scoreboard players operation $fk.uinput fokus.rrv += $fk.linput fokus.rrv