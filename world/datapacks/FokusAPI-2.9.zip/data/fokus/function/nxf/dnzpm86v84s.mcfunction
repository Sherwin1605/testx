execute if score $rl.debug rl.debug matches 1 run say Im the target;
summon arrow ~ ~2.1 ~ {Tags:["fokus.dm"],crit:false,PierceLevel:1b,life:1200,pickup:0b,Silent:true}
tag @s add fk.target
scoreboard players set @p[tag=fk.target] fk.damaged 0
execute as @e[type=arrow,sort=nearest,tag=fokus.dm,limit=1] at @s run function fokus:nxf/y20m