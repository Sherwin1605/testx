execute as @a[tag=fkapi.waittg] run function fokus:nxf/j1sxw85
execute as @a[tag=fkapi.waittg] as @s[scores={fk.tmp=99..100}] at @s run function fokus:nxf/fmbdlz5e