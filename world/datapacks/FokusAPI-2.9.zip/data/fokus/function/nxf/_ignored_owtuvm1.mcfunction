item replace entity @s weapon with air
scoreboard players set $lh83BG lArOQlvbt 1