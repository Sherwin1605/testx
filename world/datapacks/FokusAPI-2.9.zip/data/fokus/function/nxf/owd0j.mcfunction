execute as @a[tag=fkapi.waittg] run function fokus:nxf/5te7i
execute as @a[tag=fkapi.waittg] as @s[scores={fk.tmp=39..40}] at @s run function fokus:nxf/08y3