execute if score $rl.debug rl.debug matches 1 run say Im the arrow
tag @s add fokus.fired
execute if score $rl.debug rl.debug matches 1 run tellraw @a [{"text":"This player is sneaking : "},{"score":{"name":"@e[tag=fk.target,limit=1]","objective":"fk.sneaking"}},{"text":" damage"}]
execute as @s store result entity @s damage double 1.42 run scoreboard players get @e[tag=fk.target,limit=1] fk.damage
execute if score $rl.debug rl.debug matches 1 run tellraw @a [{"text":"This player will receive "},{"score":{"name":"@e[tag=fk.target,limit=1]","objective":"fk.damage"}},{"text":" damage"}]
tag @e[tag=fk.target,limit=1] remove fk.target
data modify entity @s Motion set value [0.0d,-0.7d,0.0d]