scoreboard objectives add fk.ptm minecraft.custom:minecraft.play_time
scoreboard players set $Q1NEuS2wf6 rl.basic 1