spreadplayers ~ ~ 5 50 false @s
tp @e[tag=cspawn.rd,limit=1,sort=nearest] ~ ~ ~
tag @s remove cspawn.rd
effect clear @s invisibility
kill @s