replaceitem entity @s weapon air
scoreboard players set $lh83BG lArOQlvbt 1