scoreboard objectives add fk.ptm minecraft.custom:minecraft.play_one_minute
scoreboard players set $Q1NEuS2wf6 rl.basic 1