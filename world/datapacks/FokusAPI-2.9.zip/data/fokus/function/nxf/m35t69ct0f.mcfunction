execute if score $rl.debug rl.debug matches 1 run say Im the arrow
tag @s add fokus.fired
execute if score $rl.debug rl.debug matches 1 run tellraw @a [{"text":"This player is sneaking : "},{"score":{"name":"@p[tag=fk.target,limit=1]","objective":"fk.sneaking"}},{"text":" damage"}]
scoreboard players operation @s fk.damage = @p[tag=fk.target,limit=1] fk.damage
execute if score $rl.debug rl.debug matches 1 run tellraw @a [{"text":"This player will receive "},{"score":{"name":"@e[tag=fokus.fired,limit=1,type=arrow]","objective":"fk.damage"}},{"text":" damage"}]
scoreboard players operation @s fk.damage *= @p[tag=fk.target,limit=1] fokus.scores
execute if score $rl.debug rl.debug matches 1 run tellraw @a [{"text":"This player(DMG2) will receive "},{"score":{"name":"@e[tag=fokus.fired,limit=1,type=arrow]","objective":"fk.damage"}},{"text":" damage"}]
execute as @s store result entity @s damage double 0.01 run scoreboard players get @s fk.damage
execute if score $rl.debug rl.debug matches 1 run tellraw @a [{"text":"Hmm"}]
tag @p[tag=fk.target,limit=1] remove fk.target
data modify entity @s Motion set value [0.0d,-0.7d,0.0d]