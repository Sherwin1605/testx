execute if score MinecraftVersion VersionInfo matches 3..9 run function fokus:nxf/tv15949ngq
execute if score MinecraftVersion VersionInfo matches 10.. run function fokus:nxf/yyzof48b