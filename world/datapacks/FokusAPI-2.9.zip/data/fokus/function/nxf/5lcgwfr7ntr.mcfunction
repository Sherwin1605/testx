execute as @s[scores={fokus.scores=1}] at @s run summon zombie ~ ~ ~
execute as @s[scores={fokus.scores=2}] at @s run summon skeleton ~ ~ ~
execute as @s[scores={fokus.scores=3}] at @s run summon creeper ~ ~ ~
execute as @s[scores={fokus.scores=4}] at @s run summon blaze ~ ~ ~
execute as @s[scores={fokus.scores=5}] at @s run summon minecraft:wither_skeleton ~ ~ ~
execute as @s[scores={fokus.scores=6}] at @s run summon minecraft:illusioner ~ ~ ~
execute as @s[scores={fokus.scores=7}] at @s run summon minecraft:phantom ~ ~ ~ {Tags:["firept"]}
execute as @s[scores={fokus.scores=8}] at @s run summon minecraft:creeper ~ ~ ~ {powered:1b}