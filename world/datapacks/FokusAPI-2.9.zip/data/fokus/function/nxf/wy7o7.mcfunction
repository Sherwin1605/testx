execute as @a[tag=fkapi.waittg] run function fokus:nxf/flpt8rfssmm
execute as @a[tag=fkapi.waittg] as @s[scores={fk.tmp=29..30}] at @s run function fokus:nxf/83lw7rb3