scoreboard players set @s clat.rslt 0
scoreboard players add $limit clat.limit 0
scoreboard players operation @s clat.cache = @s clat.base
scoreboard players operation @s clat.cache %= $limit clat.limit
scoreboard players operation @s clat.rslt = @s clat.cache