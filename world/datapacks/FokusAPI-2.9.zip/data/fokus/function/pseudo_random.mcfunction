scoreboard players set #-2147483648 fokus.rrv -2147483648
scoreboard players set #1103515245 fokus.rrv 1103515245
scoreboard players set #32768 fokus.rrv 32768
scoreboard players set #65536 fokus.rrv 65536
scoreboard players operation #math__randomp__current fokus.rrv *= #1103515245 fokus.rrv
execute store result score #math__randomp__lower fokus.rrv run scoreboard players add #math__randomp__current fokus.rrv 12345
scoreboard players operation #math__randomp__lower fokus.rrv /= #65536 fokus.rrv
scoreboard players operation #math__randomp__current fokus.rrv *= #1103515245 fokus.rrv
execute store result score $fk.oput fokus.rrv run scoreboard players add #math__randomp__current fokus.rrv 12345
scoreboard players operation $fk.oput fokus.rrv /= #32768 fokus.rrv
scoreboard players operation $fk.oput fokus.rrv *= #32768 fokus.rrv
execute if score #math__randomp__lower fokus.rrv matches ..-1 if score $fk.oput fokus.rrv matches 0.. run scoreboard players operation $fk.oput fokus.rrv += #-2147483648 fokus.rrv
execute if score #math__randomp__lower fokus.rrv matches 0.. if score $fk.oput fokus.rrv matches ..-1 run scoreboard players operation $fk.oput fokus.rrv += #-2147483648 fokus.rrv
scoreboard players operation $fk.oput fokus.rrv += #math__randomp__lower fokus.rrv
scoreboard players operation $fk.uinput fokus.rrv -= $fk.linput fokus.rrv
execute store result score $fk.oput fokus.rrv run scoreboard players operation $fk.oput fokus.rrv %= $fk.uinput fokus.rrv
scoreboard players operation $fk.oput fokus.rrv += $fk.linput fokus.rrv
scoreboard players operation $fk.uinput fokus.rrv += $fk.linput fokus.rrv