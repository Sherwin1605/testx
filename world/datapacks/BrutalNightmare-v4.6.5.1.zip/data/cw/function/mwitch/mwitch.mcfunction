schedule function cw:mwitch/mwitch 250s
execute at @a as @e[type=witch,tag=!witcher_passenger,limit=1,sort=nearest,distance=..50] at @s if predicate cw:r10 run function cw:mwitch/mwitch_summon