schedule function cw:mwitch/spread 30s
execute as @e[tag=witcher_passenger,type=witch] at @s if entity @p[distance=0..3] if predicate cw:r30 run spreadplayers ~-3 ~-3 3 1 false @p[distance=0..3]