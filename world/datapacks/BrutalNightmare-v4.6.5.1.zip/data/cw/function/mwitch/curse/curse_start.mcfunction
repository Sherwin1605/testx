tag @s add fr.curse
execute at @s run summon armor_stand ~ ~ ~ {Invisible:true,Invulnerable:true,Tags:["freeze_curse"],Glowing:false}
title @a times 20 100 20
title @a subtitle {"text":"Hold sneak to escape"}
title @a title ["",{"text":"\u2554 "},{"text":"Curse ","color":"dark_red"},{"text":"of the "},{"text":"Witch ","color":"dark_blue"},{"text":"\u2557"}]