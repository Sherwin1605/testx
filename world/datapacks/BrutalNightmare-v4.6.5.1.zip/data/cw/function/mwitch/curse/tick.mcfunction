schedule function cw:mwitch/curse/tick 1t
execute at @a[tag=fr.curse] as @e[type=armor_stand,limit=1,sort=nearest,tag=freeze_curse] if entity @p[limit=1,sort=nearest,tag=fr.curse,scores={glob.shift2=0..49}] at @s run function cw:mwitch/curse/cursing
execute at @a[tag=fr.curse] as @e[type=armor_stand,limit=1,sort=nearest,tag=freeze_curse] if entity @p[limit=1,sort=nearest,tag=fr.curse,scores={glob.shift2=50..}] run function cw:mwitch/curse/end_curse
execute as @a[scores={glob.shift2=51..},tag=fr.curse] run scoreboard players set @s glob.shift2 0
execute as @a[scores={glob.shift2=1..},tag=!fr.curse] run scoreboard players set @s glob.shift2 0