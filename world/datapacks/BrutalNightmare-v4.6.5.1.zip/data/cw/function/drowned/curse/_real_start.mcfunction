schedule function cw:drowned/curse/_real_start 5s
scoreboard players add @a dr.dr_curse 0
scoreboard players add @a dr.dr_curse_cd 0