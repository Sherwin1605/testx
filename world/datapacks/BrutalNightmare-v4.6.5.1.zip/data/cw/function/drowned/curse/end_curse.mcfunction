tag @p[limit=1,sort=nearest,tag=dr.curse,scores={glob.shift=50..}] remove dr.curse
kill @s