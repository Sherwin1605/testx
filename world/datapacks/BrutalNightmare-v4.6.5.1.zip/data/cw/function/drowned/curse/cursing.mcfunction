scoreboard players set $fYBbX k146xYV8Q8 0
execute if score $fYBbX k146xYV8Q8 matches 0 run function cw:nxf/cursing_ezrn81tei
execute if score $fYBbX k146xYV8Q8 matches 0 run function cw:nxf/cursing_n7vcy8uz4d
scoreboard players set $fYBbX k146xYV8Q8 0