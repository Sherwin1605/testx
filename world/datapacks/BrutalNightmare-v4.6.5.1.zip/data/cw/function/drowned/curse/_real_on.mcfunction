schedule function cw:drowned/curse/_real_on 10s
execute as @a[tag=!dr.curse,scores={dr.dr_curse_cd=0,dr.dr_curse=0}] at @s if entity @e[type=drowned,distance=0..5] as @s if predicate cw:r30 run playsound minecraft:entity.skeleton_horse.death record @s ~ ~ ~ 1000 0.1
execute as @a[tag=!dr.curse,scores={dr.dr_curse_cd=0,dr.dr_curse=1}] run function cw:drowned/curse/curse
execute as @a[tag=!dr.curse,scores={dr.dr_curse_cd=0,dr.dr_curse=0}] at @s if entity @e[type=drowned,distance=0..5] as @s if predicate cw:r30 run scoreboard players set @s dr.dr_curse 1