summon armor_stand ~ ~ ~ {Invisible:true,Invulnerable:true,Tags:["drowned_curse"],Glowing:false}
title @s times 20 100 20
title @s subtitle {"text":"Hold sneak to escape"}
title @s title ["",{"text":"\u2554 "},{"text":"Curse ","color":"dark_red"},{"text":"of the "},{"text":"Ocean ","color":"dark_blue"},{"text":"\u2557"}]