tag @s add dr.curse
scoreboard players set @s dr.dr_curse 0
execute as @s at @s if block ~ ~ ~ water if block ~ ~-3 ~ water run function cw:nxf/curse_pd7vbasi
scoreboard players set $AaX3h9L k146xYV8Q8 0
execute if score $AaX3h9L k146xYV8Q8 matches 0 run function cw:nxf/curse_0o3n
execute if score $AaX3h9L k146xYV8Q8 matches 0 run function cw:nxf/curse_btlefp6h8j
scoreboard players set $AaX3h9L k146xYV8Q8 0