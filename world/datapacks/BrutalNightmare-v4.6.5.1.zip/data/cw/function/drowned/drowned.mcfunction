schedule function cw:drowned/drowned 7s
execute as @a at @s if entity @e[type=drowned,distance=0..5] at @e[type=drowned,distance=0..7,limit=1] run function cw:nxf/drowned_bjmrs40wu