execute if score MinecraftVersion VersionInfo matches 4.. run function cw:nxf/nosleep_4x__fhnaj
execute if score MinecraftVersion VersionInfo matches 3 run function cw:nxf/nosleep_3__gv2e