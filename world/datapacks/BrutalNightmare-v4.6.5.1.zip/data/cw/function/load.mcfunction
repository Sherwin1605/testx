scoreboard objectives add rl.basic dummy
scoreboard objectives add k146xYV8Q8 dummy
scoreboard objectives add islib dummy
scoreboard objectives add ismodded dummy
scoreboard players set Modded ismodded 0
schedule function cw:load_welcome 5s
scoreboard players set $fokus.rn islib 0
function fokus:islib
execute unless score $fokus.rn islib matches 1 run tellraw @a {"text":"[BrutalNightmare] Please install FokusAPI for this pack","bold":true,"color":"green"}
execute unless score $fokus.rn islib matches 1 run schedule function cw:load 5s
scoreboard players set $reactify.rn islib 0
function reactify:islib
execute unless score $reactify.rn islib matches 1 run tellraw @a {"text":"[BrutalNightmare] Please install Reactify for this pack","bold":true,"color":"green"}
execute unless score $reactify.rn islib matches 1 run schedule function cw:load 5s
execute if score $fokus.rn islib matches 1 if score $reactify.rn islib matches 1 run function cw:load_rlixld