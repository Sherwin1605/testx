execute if score $psive.fb st.activate matches 1 run function cw:nxf/ncow_kg3fqxy7fu
execute unless score $psive.fb st.activate matches 1 run function cw:nxf/ncow_qrjdqmr8ke