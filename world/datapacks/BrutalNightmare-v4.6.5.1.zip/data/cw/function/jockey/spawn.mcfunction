schedule function cw:jockey/spawn 140s
execute as @r[limit=10] at @s if predicate cw:r10 run function cw:nxf/spawn_szas4wd4k