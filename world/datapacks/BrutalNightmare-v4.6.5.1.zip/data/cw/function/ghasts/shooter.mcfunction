schedule function cw:ghasts/shooter 1s
execute as @a[gamemode=survival] at @s as @e[type=ghast,distance=..40,tag=gh.rn,scores={gh.fball=1..}] at @s run function cw:nxf/shooter_wlxd6m0imk
execute as @a[gamemode=survival] at @s as @e[type=ghast,distance=..40,tag=gh.rn,scores={gh.fball=0}] run tag @s remove gh.rn