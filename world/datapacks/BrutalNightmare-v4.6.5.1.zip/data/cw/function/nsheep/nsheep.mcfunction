execute if score $psive.fb st.activate matches 1 run function cw:nxf/nsheep_q250l1v2
execute unless score $psive.fb st.activate matches 1 run function cw:nxf/nsheep_0doca