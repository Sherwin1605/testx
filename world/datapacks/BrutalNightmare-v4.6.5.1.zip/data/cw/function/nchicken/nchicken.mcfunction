execute if score $psive.fb st.activate matches 1 run function cw:nxf/nchicken_84t7g826u5
execute unless score $psive.fb st.activate matches 1 run function cw:nxf/nchicken_x54x