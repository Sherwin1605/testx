scoreboard objectives add cw.isrunning dummy
scoreboard objectives add islib dummy
function fokus:tks_1sec
scoreboard objectives add ismodded dummy
scoreboard players set Modded ismodded 0
scoreboard objectives add rl.debug dummy
scoreboard objectives add k146xYV8Q8 dummy
scoreboard objectives add VersionInfo dummy
scoreboard players add MinecraftVersion VersionInfo 0
function fokus:vd/cores/1.14
# First Launch
scoreboard objectives add cw.fl dummy
scoreboard objectives add cw.em.my dummy
# Enhanced Mob
scoreboard objectives add cr.dsg dummy
scoreboard objectives add em.edm_curse dummy
scoreboard objectives add em.edm_curse_cd dummy
scoreboard objectives add glob.shift minecraft.custom:sneak_time
scoreboard objectives add glob.shift2 minecraft.custom:sneak_time
scoreboard objectives add dr.dr_curse_cd dummy
scoreboard objectives add dr.dr_curse dummy
scoreboard objectives add sv.infect_cd dummy
scoreboard objectives add wt.sm dummy
scoreboard objectives add sb.abil dummy
scoreboard objectives add mw.burn dummy
scoreboard objectives add st.activate dummy
scoreboard objectives add st.success dummy
scoreboard objectives add posY dummy
scoreboard objectives add min.posY dummy
scoreboard objectives add gl.pathAv dummy
scoreboard objectives add vdvcasttemp dummy
scoreboard objectives add blaze.tt minecraft.used:minecraft.totem_of_undying
scoreboard objectives add kill.cow minecraft.killed:minecraft.cow
scoreboard objectives add kill.sheep minecraft.killed:minecraft.sheep
scoreboard objectives add kill.chicken minecraft.killed:minecraft.chicken
scoreboard objectives add kill.horse minecraft.killed:minecraft.horse
scoreboard objectives add zb.hmet dummy
scoreboard objectives add zb.hmet_0 dummy
scoreboard objectives add sk.hmet dummy
scoreboard objectives add sk.hmet_0 dummy
scoreboard objectives add sl.size dummy
scoreboard objectives add sv.cure minecraft.used:minecraft.potion
scoreboard objectives add vdn.ilook dummy
scoreboard objectives add vdn.noai dummy
scoreboard objectives add vdn.dc dummy
scoreboard objectives add vdn.count dummy
scoreboard objectives add ptom.sc dummy
scoreboard objectives add ptom.dropnd dummy
scoreboard objectives add gh.fball dummy
scoreboard objectives add sk.arr dummy
scoreboard objectives add jk.rdum dummy
# Flaunch
scoreboard objectives add cw.y dummy
scoreboard objectives add cw.menu.page dummy
scoreboard players add $cw.fs cw.fl 0
scoreboard players add $cw.fs cw.menu.page 0
execute unless score $cw.fs cw.fl matches 1 run function cw:firstlaunch
# Main
function cw:extend/extend
scoreboard players add $cw.fs cw.fl 0
scoreboard players add $cw.fs cw.menu.page 0
execute if score $nosleep st.activate matches 1 run function cw:nosleep
execute if score $em.curse st.activate matches 1 run function cw:em/em
execute if score $em.curse st.activate matches 1 run function cw:em/em_cs
execute if score $em.curse st.activate matches 1 run function cw:em/enderman
execute if score $em.caskill st.activate matches 1 run function cw:em/telem_touch
execute if score $ws.caskill st.activate matches 1 run function cw:witherskeleton/wskeleton
execute if score $dr.caskill st.activate matches 1 run function cw:drowned/drowned
execute if score $dr.curse st.activate matches 1 run function cw:drowned/curse/tick
execute if score $dr.curse st.activate matches 1 run function cw:drowned/curse/tick
execute if score $dr.curse st.activate matches 1 run function cw:drowned/curse/_real_countdown
execute if score $dr.curse st.activate matches 1 run function cw:drowned/curse/_real_on
execute if score $dr.curse st.activate matches 1 run function cw:drowned/curse/_real_start
execute if score $sp.shtweb st.activate matches 1 run function cw:spider/spider
execute if score $sk.gattshot st.activate matches 1 run function cw:skeleton/ske_gatling
execute if score $sk.gattshot st.activate matches 1 run function cw:skeleton/shooter
execute if score $sk.caskill st.activate matches 1 run function cw:skeleton/skeleton
execute if score $sk.smai st.activate matches 1 run function cw:skeleton/swapper
execute if score $sk.noburn st.activate matches 1 run function cw:skeleton/ssmob
execute if score $mw.enable st.activate matches 1 run function cw:mwitch/mwitch
execute if score $mw.burning st.activate matches 1 run function cw:mwitch/burning
execute if score $mw.freeze st.activate matches 1 run function cw:mwitch/freeze
execute if score $mw.freeze st.activate matches 1 run function cw:mwitch/curse/tick
execute if score $mw.leviation st.activate matches 1 run function cw:mwitch/leviation
execute if score $mw.spread st.activate matches 1 run function cw:mwitch/spread
execute if score $mw.drop st.activate matches 1 run function cw:mwitch/drop
execute if score $zb.pblock st.activate matches 1 run function cw:zombie/placeblock
execute if score $zb.pblock st.activate matches 1 run function cw:zombie/placeblock_under
execute if score $zb.pblock st.activate matches 1 run function cw:husk/placeblock
execute if score $zb.pblock st.activate matches 1 run function cw:husk/placeblock_under
execute if score $zb.bblock st.activate matches 1 run function cw:zombie/breakblock
execute if score $zb.bblock st.activate matches 1 run function cw:husk/breakblock
execute if score $zb.bblock st.activate matches 1 run function cw:zombie/placeblock_under
execute if score $zb.bblock st.activate matches 1 run function cw:husk/placeblock_under
execute if score $zb.ttnt st.activate matches 1 run function cw:zombie/zombie_throw_tnt
execute if score $zb.ttnt st.activate matches 1 run function cw:husk/husk_throw_tnt
execute if score $zb.smoften st.activate matches 1 run function cw:zombie/random_spawn
execute if score $zb.noburn st.activate matches 1 run function cw:zombie/ssmob
execute if score $cr.smai st.activate matches 1 run function cw:screeper
execute if score $cr.sap st.activate matches 1 run function cw:creeper/random_summon
execute if score $bl.caskill st.activate matches 1 run function cw:blaze/doubler
execute if score $bl.usecurse st.activate matches 1 run function cw:blaze/use_curse
execute if score $bl.spawnao st.activate matches 1 run function cw:blaze/spawn
function cw:nsheep/nsheep
function cw:ncow/ncow
function cw:nchicken/nchicken
function cw:nhorse/nhorse
execute if score $slime.sb st.activate matches 1 run function cw:slime/ddamage
execute if score $slime.sb st.activate matches 1 run function cw:slime/loop
execute if score $sfish.ife st.activate matches 1 run function cw:silverfish/infection
execute if score $sfish.ife st.activate matches 1 run function cw:silverfish/infect_loop
execute if score $vd.statue st.activate matches 1 run function cw:vindicator/nvin_kars
execute if score $vd.statue st.activate matches 1 run function cw:vindicator/nvin
execute if score $vd.statue st.activate matches 1 run function cw:vindicator/nvin_summon
execute if score $cr.ssnow st.activate matches 1 run function cw:creeper/creeper_shoot_snowball
execute if score $ptom.sleep st.activate matches 1 run function cw:phantom/sleep_nm
execute if score $ptom.sleep st.activate matches 1 run function cw:phantom/firept
execute if score $ptom.rsum st.activate matches 1 run function cw:phantom/rsummon
execute if score $ptom.rsum st.activate matches 1 run function cw:phantom/firept
execute if score $ptom.carry st.activate matches 1 run function cw:phantom/carry
execute if score $ptom.carry st.activate matches 1 run function cw:phantom/drop
execute if score $mob.inv st.activate matches 1 run function cw:invisiblem
execute if score $gh.smul st.activate matches 1 run function cw:ghasts/gh_gatling
execute if score $gh.smul st.activate matches 1 run function cw:ghasts/shooter
execute if score $ilu.rsum st.activate matches 1 run function cw:illusioner/randomspawn
execute if score $cr.disguide st.activate matches 1 run function cw:creeper/disguide_summon
execute if score $cr.disguide st.activate matches 1 run function cw:creeper/end_disguide
execute if score $cr.disguide st.activate matches 1 run function cw:creeper/boom_disguide
execute if score $jk.rsum st.activate matches 1 run function cw:jockey/spawn
execute if score $jk.rsum st.activate matches 1 run function cw:jockey/jockey_speed
execute if score $wm.rsum st.activate matches 1 run function cw:watermob/move
execute if score $wm.rsum st.activate matches 1 run function cw:watermob/random_popup
execute if score $wm.rsum st.activate matches 1 run function cw:watermob/summon
execute if score $zb.newabi st.activate matches 1 run function cw:zombie/ability
execute if score $zb.newabi st.activate matches 1 run function cw:husk/ability
execute if score $hardattrb st.activate matches 1 run function cw:hardattrb/hardattrb
execute if score $dashforward st.activate matches 1 run function cw:hardattrb/dashforward