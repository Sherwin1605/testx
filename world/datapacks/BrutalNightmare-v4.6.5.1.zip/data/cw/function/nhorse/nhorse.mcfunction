execute if score $psive.fb st.activate matches 1 run function cw:nxf/nhorse_omubm78847
execute unless score $psive.fb st.activate matches 1 run function cw:nxf/nhorse_7eq4o0n5u