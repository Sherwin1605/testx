schedule function cw:hardattrb/hardattrb 2s
execute as @r[gamemode=survival,limit=10] at @s as @e[type=#cw:hostile,distance=..7,limit=3,tag=!noattr] at @s run function cw:nxf/hardattrb_1h7p5vki