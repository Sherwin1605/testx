schedule function cw:em/telem_touch 4s
execute as @a at @s as @e[type=enderman,distance=0..4,nbt=!{AngerTime:0},limit=1] at @s if predicate cw:r45 run function cw:nxf/telem_touch_o6p8rcc