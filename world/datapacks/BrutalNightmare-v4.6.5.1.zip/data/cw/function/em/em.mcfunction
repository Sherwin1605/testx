schedule function cw:em/em 5s
scoreboard players add @a em.edm_curse 0
scoreboard players add @a em.edm_curse_cd 0
scoreboard players add @a glob.shift 0
scoreboard players add @a glob.shift2 0