execute as @s at @s run tp @s ~ ~ ~ facing entity @p[limit=1,sort=nearest] feet
execute as @s at @s as @p[limit=1,sort=nearest] at @s run tp @s ~ ~ ~ facing entity @e[type=enderman,limit=1,sort=nearest] eyes
execute as @s at @s run effect give @p[limit=1,sort=nearest] minecraft:instant_damage 1 0
data modify entity @s AngryAt set from entity @p[limit=1,sort=nearest] UUID
data modify entity @s AngerTime set value 425
execute as @s at @s run tp @s ~ ~ ~ facing entity @p[limit=1,sort=nearest] feet
tag @s remove cursed_enderman