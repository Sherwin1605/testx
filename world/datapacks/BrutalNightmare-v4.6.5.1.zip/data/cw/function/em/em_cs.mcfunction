schedule function cw:em/em_cs 450s
execute as @a[scores={em.edm_curse_cd=1..}] run scoreboard players remove @s em.edm_curse_cd 1