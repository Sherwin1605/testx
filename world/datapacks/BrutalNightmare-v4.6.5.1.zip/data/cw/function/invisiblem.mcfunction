schedule function cw:invisiblem 12s
execute as @a at @s as @e[type=phantom,distance=..30,sort=random,limit=6,tag=!cw.given] at @s if predicate cw:r45 run function cw:nxf/invisiblem_nxl4
execute as @a at @s as @e[type=enderman,distance=..30,sort=random,limit=6,tag=!cw.given] at @s if predicate cw:r45 run function cw:nxf/invisiblem_5q8p
execute as @a at @s as @e[type=spider,distance=..30,sort=random,limit=6,tag=!cw.given] at @s if predicate cw:r45 run function cw:nxf/invisiblem_04qit2i9