execute as @e[type=cow,tag=fkapi.waittg] run function cw:nxf/ncow_mhia
execute as @e[type=cow,tag=fkapi.waittg] as @s[scores={fk.tmp=29..30}] at @s run function cw:nxf/ncow_4yqj