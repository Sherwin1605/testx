setblock ~ ~ ~ dirt keep
tp ~ ~1 ~