tag @s add cw.enderp
scoreboard players set $UGXU k146xYV8Q8 0
execute if score $UGXU k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_hl7u77upev
execute if score $UGXU k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_u8plwvo
scoreboard players set $UGXU k146xYV8Q8 0
tag @s add specabi
scoreboard players set $DzU4z8eRn k146xYV8Q8 1