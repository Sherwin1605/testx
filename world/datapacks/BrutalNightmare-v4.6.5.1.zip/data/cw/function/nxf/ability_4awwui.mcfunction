tag @s add cw.shield
scoreboard players set $l4JhF k146xYV8Q8 0
execute if score $l4JhF k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_x8nt8v
execute if score $l4JhF k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_jp7n
scoreboard players set $l4JhF k146xYV8Q8 0
scoreboard players set $1vXmDyFU3 k146xYV8Q8 0
execute if score $1vXmDyFU3 k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_5o3cisaype
execute if score $1vXmDyFU3 k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_k9bijw6653
scoreboard players set $1vXmDyFU3 k146xYV8Q8 0
tag @s add specabi
scoreboard players set $KNs8.Mk k146xYV8Q8 1