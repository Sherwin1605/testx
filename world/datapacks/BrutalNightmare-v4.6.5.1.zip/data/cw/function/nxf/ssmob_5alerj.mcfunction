execute if score MinecraftVersion VersionInfo matches 3..13 run function cw:nxf/ssmob_3x13__9p7mx2
execute if score MinecraftVersion VersionInfo matches 14.. run function cw:nxf/ssmob_14x__6hunw9s
tag @s add zb.wss
execute as @s[scores={zb.hmet_0=0}] run function cw:nxf/ssmob_z4f0