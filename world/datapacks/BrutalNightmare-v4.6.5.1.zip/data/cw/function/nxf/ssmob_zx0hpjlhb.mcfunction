execute if score MinecraftVersion VersionInfo matches 3..13 run function cw:nxf/ssmob_3x13__0eomjo5y
execute if score MinecraftVersion VersionInfo matches 14.. run function cw:nxf/ssmob_14x__3hx6w
tag @s add sk.wss
execute as @s[scores={sk.hmet_0=0}] run function cw:nxf/ssmob_nbv0medj46