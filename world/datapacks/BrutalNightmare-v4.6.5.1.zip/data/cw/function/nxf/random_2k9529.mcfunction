scoreboard players set @s fokus.scores 8
function fokus:spawn
scoreboard players set $MN.K k146xYV8Q8 1