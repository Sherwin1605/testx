tag @s add cw.onlyme
tag @s add cw.pickaxe_tl
scoreboard players set $ZbVW5mcari k146xYV8Q8 0
execute if score $ZbVW5mcari k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_774h
execute if score $ZbVW5mcari k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_r611zl6xt9
scoreboard players set $ZbVW5mcari k146xYV8Q8 0
tag @s add specabi
scoreboard players set $KNs8.Mk k146xYV8Q8 1