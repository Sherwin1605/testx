execute if score MinecraftVersion VersionInfo matches 3..13 run function cw:nxf/ssmob_3x13__s6kcn
execute if score MinecraftVersion VersionInfo matches 14.. run function cw:nxf/ssmob_14x__7r7z0hm
tag @s add zb.wss
execute as @s[scores={zb.hmet_0=0}] run function cw:nxf/ssmob_85jtkwwdhp7