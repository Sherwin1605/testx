summon vindicator ~ ~ ~ {CustomName:'[{"text":"Nightmare","bold":true,"color":"dark_red"}]',Invulnerable:1b,PersistenceRequired:1b,NoAI:1b,Silent:1b,Tags:["cw.nmsp","cw.nmstart"],HandItems:[{id:diamond_axe,Count:1}],Attributes:[{Name:"generic.movement_speed",Base:0.45f}],HandDropChances:[0f]}
kill @s
execute as @e[type=vindicator,tag=cw.nmstart] at @s run function cw:nxf/nvin_i2ygv