execute as @e[type=chicken,tag=!angry_chicken,distance=..7] at @s run function cw:nxf/nchicken_s15negc6o0z
kill @s