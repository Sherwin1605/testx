title @a[distance=..15] actionbar ["",{"text":"You defeated IT","color":"dark_red","bold":true}]
function fokus:disappear