execute as @s at @s unless block ~ ~-4 ~ water run tag @s remove dr.curse
scoreboard players set $AaX3h9L k146xYV8Q8 1