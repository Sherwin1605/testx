schedule function cw:ncow/ncow 5t
execute if score MinecraftVersion VersionInfo matches 3..10 run function cw:nxf/ncow_3x10__hh6ow
execute if score MinecraftVersion VersionInfo matches 11.. run function cw:nxf/ncow_11x__3auptuc5k