effect give @s minecraft:speed 999999 1
tag @s remove speeder