execute if score MinecraftVersion VersionInfo matches 3..5 run function cw:nxf/_ignored_doubler_3x5__jaum3
execute if score MinecraftVersion VersionInfo matches 6..7 run function cw:nxf/_ignored_doubler_6x7__bpw76fe
execute if score MinecraftVersion VersionInfo matches 8.. run function cw:nxf/_ignored_doubler_8x__elb7t4t