attribute @s minecraft:knockback_resistance base set 1
scoreboard players set $wsd7tM9o58 k146xYV8Q8 1