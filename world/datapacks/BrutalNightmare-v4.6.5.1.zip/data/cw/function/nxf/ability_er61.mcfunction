scoreboard players set $mp85ZYr5xKg k146xYV8Q8 0
execute if score $mp85ZYr5xKg k146xYV8Q8 matches 0 if entity @p[distance=5..7] run function cw:nxf/ability_w9yssa
execute if score $mp85ZYr5xKg k146xYV8Q8 matches 0 if entity @p[distance=8..18] run function cw:nxf/ability_5nm1lbw
scoreboard players set $mp85ZYr5xKg k146xYV8Q8 0