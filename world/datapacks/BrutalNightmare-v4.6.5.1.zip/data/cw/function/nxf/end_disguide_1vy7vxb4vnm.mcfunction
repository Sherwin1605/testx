function fokus:disappear
execute if score $rl.debug rl.debug matches 1 run say Nooo!