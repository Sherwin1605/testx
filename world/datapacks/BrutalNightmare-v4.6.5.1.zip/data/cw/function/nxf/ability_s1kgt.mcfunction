execute if score $zb.allbreaker st.activate matches 1 run function cw:nxf/ability_4gcx4
execute unless score $zb.allbreaker st.activate matches 1 run function cw:nxf/ability_8tcjzb
scoreboard players set $DzU4z8eRn k146xYV8Q8 0
execute if score $DzU4z8eRn k146xYV8Q8 matches 0 as @s[scores={sb.abil=0}] run function cw:nxf/ability_9j8m1vblb15
execute if score $DzU4z8eRn k146xYV8Q8 matches 0 as @s[scores={sb.abil=1}] run function cw:nxf/ability_ghz3
execute if score $DzU4z8eRn k146xYV8Q8 matches 0 as @s[scores={sb.abil=2}] run function cw:nxf/ability_4dhq3
execute if score $DzU4z8eRn k146xYV8Q8 matches 0 as @s[scores={sb.abil=3}] run function cw:nxf/ability_n37z
execute if score $DzU4z8eRn k146xYV8Q8 matches 0 as @s[scores={sb.abil=4}] run function cw:nxf/ability_qm2cz
scoreboard players set $DzU4z8eRn k146xYV8Q8 0