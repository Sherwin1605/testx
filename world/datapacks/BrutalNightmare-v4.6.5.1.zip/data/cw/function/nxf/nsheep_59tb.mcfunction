execute as @e[type=sheep,tag=fkapi.waittg] run function cw:nxf/nsheep_cght7p
execute as @e[type=sheep,tag=fkapi.waittg] as @s[scores={fk.tmp=29..30}] at @s run function cw:nxf/nsheep_mb68lvu