replaceitem entity @s weapon.offhand stone_axe
scoreboard players set $UKe55G k146xYV8Q8 1