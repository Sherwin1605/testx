execute if score MinecraftVersion VersionInfo matches 3..7 run function cw:nxf/zombie_3x7__3u2k
execute if score MinecraftVersion VersionInfo matches 8.. run function cw:nxf/zombie_8x__vjxzlyt0gs
execute as @e[type=tnt,tag=ame] at @s facing entity @p eyes positioned ~ ~1.3 ~ run function cw:nxf/zombie_pqydsm7y