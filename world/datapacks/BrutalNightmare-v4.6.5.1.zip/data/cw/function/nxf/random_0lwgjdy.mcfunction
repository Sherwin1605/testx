scoreboard players set @s fokus.scores 3
function fokus:spawn