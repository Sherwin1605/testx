scoreboard players add @s vdn.count 0
scoreboard players set @s vdn.ilook 0
execute as @a[distance=..30] at @s anchored eyes facing entity @e[type=minecraft:vindicator] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.1] at @s run scoreboard players set @e[type=vindicator,tag=cw.nm,distance=..30,sort=nearest,limit=1] vdn.ilook 1
scoreboard players add @s vdn.noai 0
execute as @s[scores={vdn.ilook=0}] if entity @s[scores={vdn.noai=1}] run function cw:nxf/nvin_co0szl0i
execute as @s[scores={vdn.ilook=0}] if entity @s[scores={vdn.noai=0}] at @s run function cw:nxf/nvin_f0gf2my
execute as @s[scores={vdn.ilook=1}] unless entity @s[scores={vdn.noai=1}] run function cw:nxf/nvin_i6fi2
execute if block ~ ~ ~ torch run function cw:nxf/nvin_kq7srmisnc
execute as @s[scores={vdn.dc=5..}] run function cw:nxf/nvin_tongsaqoc