scoreboard players set $XDbhK.g k146xYV8Q8 0
execute if score $XDbhK.g k146xYV8Q8 matches 0 run function cw:nxf/_ignored_summon_6x5hggdkwf
execute if score $XDbhK.g k146xYV8Q8 matches 0 run function cw:nxf/_ignored_summon_qknhcpe
scoreboard players set $XDbhK.g k146xYV8Q8 0
tag @s remove wt.axe