scoreboard players set @p sv.infect_cd 4
function fokus:disappear