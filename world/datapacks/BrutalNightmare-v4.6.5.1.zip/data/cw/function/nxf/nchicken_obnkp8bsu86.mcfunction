scoreboard players set @s fk.et.ptm 0
scoreboard players set @s fk.tmp 0
tag @s remove fkapi.waittg
execute if score MinecraftVersion VersionInfo matches 3..7 run function cw:nxf/nchicken_3x7__y1d1t3g3n
execute if score MinecraftVersion VersionInfo matches 8..11 run function cw:nxf/nchicken_8x11__3gfogff262o
execute if score MinecraftVersion VersionInfo matches 12.. run function cw:nxf/nchicken_12x__n9hqkjqv44
function fokus:disappear