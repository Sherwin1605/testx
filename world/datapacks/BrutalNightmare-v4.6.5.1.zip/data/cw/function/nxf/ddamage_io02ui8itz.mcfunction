scoreboard players set @s fk.damage 2
function fokus:dealt_damage