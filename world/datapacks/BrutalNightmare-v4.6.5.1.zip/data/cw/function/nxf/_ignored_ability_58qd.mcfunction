replaceitem entity @s weapon.offhand shield
scoreboard players set $fiMrT9YQQ k146xYV8Q8 1