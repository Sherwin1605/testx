attribute @s minecraft:knockback_resistance base set 1
scoreboard players set $1vXmDyFU3 k146xYV8Q8 1