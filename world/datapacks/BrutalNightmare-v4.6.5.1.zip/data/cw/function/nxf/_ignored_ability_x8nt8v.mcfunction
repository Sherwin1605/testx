replaceitem entity @s weapon.offhand shield
scoreboard players set $l4JhF k146xYV8Q8 1