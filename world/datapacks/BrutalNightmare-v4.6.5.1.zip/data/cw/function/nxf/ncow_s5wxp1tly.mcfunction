summon armor_stand ~ ~-1 ~ {Invulnerable:1b,Invisible:1b,Tags:["fokus.cow"]}
execute at @s as @e[type=armor_stand,tag=fokus.cow,sort=nearest,limit=1,distance=..5] at @s run function cw:nxf/ncow_0ibs55
kill @s