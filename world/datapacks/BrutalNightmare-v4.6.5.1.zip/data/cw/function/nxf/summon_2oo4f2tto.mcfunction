scoreboard players set $SC.bO5JW k146xYV8Q8 0
execute if score $SC.bO5JW k146xYV8Q8 matches 0 run function cw:nxf/_ignored_summon_ikjdbnpuf8
execute if score $SC.bO5JW k146xYV8Q8 matches 0 run function cw:nxf/_ignored_summon_22t3o9su
scoreboard players set $SC.bO5JW k146xYV8Q8 0
tag @s remove wt.bow