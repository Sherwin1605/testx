execute as @e[type=sheep,tag=fkapi.waittg] run function cw:nxf/nsheep_dou6k
execute as @e[type=sheep,tag=fkapi.waittg] as @s[scores={fk.tmp=29..30}] at @s run function cw:nxf/nsheep_v4s70