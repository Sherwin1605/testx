summon armor_stand ~ ~-1 ~ {Invulnerable:1b,Invisible:1b,Tags:["fokus.sheep"]}
execute at @s as @e[type=armor_stand,tag=fokus.sheep,sort=nearest,limit=1,distance=..5] at @s run function cw:nxf/nsheep_h7nvc
kill @s