execute if score $rl.debug rl.debug matches 1 run say Wakanda 4Ever!
summon creeper ~ ~ ~ {Fuse:10,ignited:true}
execute as @e[tag=disguider,distance=..3] at @s run function fokus:disappear
function fokus:disappear