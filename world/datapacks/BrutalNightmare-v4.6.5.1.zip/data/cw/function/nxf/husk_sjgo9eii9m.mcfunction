function fokus:apply_motion
tag @s remove ame