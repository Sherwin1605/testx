item replace entity @s weapon.offhand with flint_and_steel
scoreboard players set $EI7I k146xYV8Q8 1