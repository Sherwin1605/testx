execute as @a[scores={sv.infect_cd=2..,sv.cure=1..}] run function cw:nxf/infect_tjpc9yp24
scoreboard players remove @s sv.infect_cd 1
particle minecraft:ash ~ ~1.7 ~ 0.3 0 0.3 1 50