summon armor_stand ~ ~-1 ~ {Invulnerable:1b,Invisible:1b,Tags:["fokus.chicken"]}
execute at @s as @e[type=armor_stand,tag=fokus.chicken,sort=nearest,limit=1,distance=..5] at @s run function cw:nxf/nchicken_h1dzodxly2z
kill @s