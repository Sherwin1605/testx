tag @s add cw.flint
scoreboard players set $EI7I k146xYV8Q8 0
execute if score $EI7I k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_j1w8in0aeg1
execute if score $EI7I k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_he97s3
scoreboard players set $EI7I k146xYV8Q8 0
tag @s add specabi
scoreboard players set $KNs8.Mk k146xYV8Q8 1