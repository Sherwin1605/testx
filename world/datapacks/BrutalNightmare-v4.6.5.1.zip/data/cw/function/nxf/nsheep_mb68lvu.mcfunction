scoreboard players set @s fk.et.ptm 0
scoreboard players set @s fk.tmp 0
tag @s remove fkapi.waittg
execute if score MinecraftVersion VersionInfo matches 3..7 run function cw:nxf/nsheep_3x7__zg050
execute if score MinecraftVersion VersionInfo matches 8..11 run function cw:nxf/nsheep_8x11__jqvonev3
execute if score MinecraftVersion VersionInfo matches 12.. run function cw:nxf/nsheep_12x__26va
function fokus:disappear