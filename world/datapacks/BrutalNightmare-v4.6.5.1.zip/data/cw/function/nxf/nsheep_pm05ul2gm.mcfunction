tag @s remove angry_sheep
summon sheep ~ ~ ~
function fokus:disappear