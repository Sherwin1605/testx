execute if score $rl.debug rl.debug matches 1 run say Run!
tag @s add jk.target
summon armor_stand ~ ~ ~ {Tags:["jk.summoner"],Invisible:true}
execute as @e[type=armor_stand,tag=jk.summoner] at @s run spreadplayers ~ ~ 5 120 false @s
execute as @e[type=armor_stand,tag=jk.summoner] at @s if entity @p[distance=..12] run kill @s
execute as @e[type=armor_stand,tag=jk.summoner] at @s run function cw:nxf/spawn_dyff6
tag @s remove jk.target