schedule function cw:nchicken/nchicken 1t
execute if score MinecraftVersion VersionInfo matches 3..10 run function cw:nxf/nchicken_3x10__o0zmolx6
execute if score MinecraftVersion VersionInfo matches 11.. run function cw:nxf/nchicken_11x__6agxar63qwc
execute as @a at @s as @e[distance=..30,type=husk,tag=chicken_psg] at @s unless entity @e[type=chicken,tag=angry_chicken,distance=..2] run kill @s
execute as @e[type=chicken,tag=angry_chicken] at @s unless entity @p[distance=..25] run function cw:nxf/nchicken_tz7kqvhxw8