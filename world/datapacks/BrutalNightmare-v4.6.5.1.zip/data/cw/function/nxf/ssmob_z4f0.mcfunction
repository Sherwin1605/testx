scoreboard players set $0BFk2cISJ3F k146xYV8Q8 0
execute if score $0BFk2cISJ3F k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ssmob_62eey1dou6
execute if score $0BFk2cISJ3F k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ssmob_oha2dpm97
scoreboard players set $0BFk2cISJ3F k146xYV8Q8 0