scoreboard players set $KPGZx2PECO k146xYV8Q8 0
execute if score $KPGZx2PECO k146xYV8Q8 matches 0 run function cw:nxf/_ignored_hardattrb_rlowej0d
execute if score $KPGZx2PECO k146xYV8Q8 matches 0 run function cw:nxf/_ignored_hardattrb_kc1c9n3zr
execute if score $KPGZx2PECO k146xYV8Q8 matches 0 run function cw:nxf/_ignored_hardattrb_v45q05sd0
scoreboard players set $KPGZx2PECO k146xYV8Q8 0
scoreboard players set $p91UB6 k146xYV8Q8 0
execute if score $p91UB6 k146xYV8Q8 matches 0 run function cw:nxf/_ignored_hardattrb_knbjml
execute if score $p91UB6 k146xYV8Q8 matches 0 run function cw:nxf/_ignored_hardattrb_5fk2yw8
scoreboard players set $p91UB6 k146xYV8Q8 0
tag @s add noattr