item replace entity @s weapon.offhand with stone_pickaxe
scoreboard players set $ZbVW5mcari k146xYV8Q8 1