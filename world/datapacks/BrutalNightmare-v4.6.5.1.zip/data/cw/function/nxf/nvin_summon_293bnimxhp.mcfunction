summon armor_stand ~ ~ ~ {Tags:["fokus.summoner"],Invisible:true}
execute as @e[type=armor_stand,tag=fokus.summoner] at @s run spreadplayers ~ ~ 5 50 false @s
execute as @e[type=armor_stand,tag=fokus.summoner] at @s run function cw:nxf/nvin_9huo