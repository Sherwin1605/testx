execute as @e[type=cow,tag=!angry_cow,distance=..7] at @s run function cw:nxf/ncow_3i2hgx
kill @s