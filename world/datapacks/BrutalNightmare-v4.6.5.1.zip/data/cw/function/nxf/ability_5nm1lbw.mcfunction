function cw:zombie/shoot_edp_strong
scoreboard players set $mp85ZYr5xKg k146xYV8Q8 1