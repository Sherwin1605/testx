schedule function cw:nchicken/nchicken 5t
execute if score MinecraftVersion VersionInfo matches 3..10 run function cw:nxf/nchicken_3x10__hgvu
execute if score MinecraftVersion VersionInfo matches 11.. run function cw:nxf/nchicken_11x__ik8b8