scoreboard players set @s sv.cure 0
scoreboard players set @s sv.infect_cd 0
particle minecraft:heart ~ ~1 ~