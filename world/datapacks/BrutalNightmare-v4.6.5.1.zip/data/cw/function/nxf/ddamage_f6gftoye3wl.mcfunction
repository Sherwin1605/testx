particle minecraft:item_slime ~ ~3 ~ 0 0 0 3 70 normal
execute as @a[distance=..3] at @s run function cw:nxf/ddamage_io02ui8itz
kill @s