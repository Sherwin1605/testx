tag @s add cw.enderp
scoreboard players set $PUwN2H k146xYV8Q8 0
execute if score $PUwN2H k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_e2pojl
execute if score $PUwN2H k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_3ef88ee3r7
scoreboard players set $PUwN2H k146xYV8Q8 0
tag @s add specabi
scoreboard players set $KNs8.Mk k146xYV8Q8 1