schedule function cw:nsheep/nsheep 5t
execute if score MinecraftVersion VersionInfo matches 3..10 run function cw:nxf/nsheep_3x10__ur31j
execute if score MinecraftVersion VersionInfo matches 11.. run function cw:nxf/nsheep_11x__xio65j6idg