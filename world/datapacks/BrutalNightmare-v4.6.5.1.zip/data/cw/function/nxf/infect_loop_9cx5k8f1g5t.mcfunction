function cw:silverfish/infected
scoreboard players set @s sv.infect_cd 0