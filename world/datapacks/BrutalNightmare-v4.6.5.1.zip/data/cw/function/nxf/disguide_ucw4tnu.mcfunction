execute at @s if entity @p[distance=..8] run kill @s
execute at @s if entity @p[distance=..8] run scoreboard players set $Bmh4pb k146xYV8Q8 1