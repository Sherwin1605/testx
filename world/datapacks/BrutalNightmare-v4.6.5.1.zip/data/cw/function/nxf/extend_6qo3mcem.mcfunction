execute if score MinecraftVersion VersionInfo matches 3..10 run function cw:nxf/extend_3x10__rvl15tq
execute if score MinecraftVersion VersionInfo matches 11.. run function cw:nxf/extend_11x__n7s2p