execute at @s if entity @p[limit=1,sort=nearest,distance=..5] as @s run tp @p[limit=1,sort=nearest,distance=..5] ~ ~ ~
scoreboard players set $fYBbX k146xYV8Q8 1