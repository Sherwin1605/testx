function fokus:drop
scoreboard players set @s em.edm_curse_cd 2
playsound minecraft:entity.wither.hurt block @s ~ ~ ~ 10000 0.1 .8
summon minecraft:enderman ^ ^ ^-1 {Tags:["cursed_enderman"]}
scoreboard players set @s em.edm_curse 0