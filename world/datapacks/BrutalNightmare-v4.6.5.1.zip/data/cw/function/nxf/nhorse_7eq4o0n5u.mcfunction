schedule function cw:nhorse/nhorse 5t
execute if score MinecraftVersion VersionInfo matches 3..10 run function cw:nxf/nhorse_3x10__oc8zls4r9
execute if score MinecraftVersion VersionInfo matches 11.. run function cw:nxf/nhorse_11x__iggwlhjj