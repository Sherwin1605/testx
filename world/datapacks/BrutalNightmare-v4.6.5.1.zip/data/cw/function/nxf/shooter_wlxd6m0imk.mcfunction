execute if score $rl.debug rl.debug matches 1 run tellraw @a [{"text":"Shoot!"}]
function cw:ghasts/shoot_fireball
scoreboard players remove @s gh.fball 1