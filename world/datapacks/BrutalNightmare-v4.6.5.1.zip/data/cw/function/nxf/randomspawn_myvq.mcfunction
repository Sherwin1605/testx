scoreboard players set @s fokus.scores 6
function fokus:spawn