execute if score $rl.debug rl.debug matches 1 run say Run!
tag @s add cr.target
summon armor_stand ~ ~ ~ {Tags:["fokus.summoner"],Invisible:true}
execute as @e[type=armor_stand,tag=fokus.summoner] at @s run function cw:nxf/disguide_qag39
tag @s remove cr.target