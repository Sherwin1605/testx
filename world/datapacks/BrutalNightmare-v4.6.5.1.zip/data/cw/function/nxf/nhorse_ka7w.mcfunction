execute as @e[type=horse,tag=fkapi.waittg] run function cw:nxf/nhorse_sx3wmhfdw
execute as @e[type=horse,tag=fkapi.waittg] as @s[scores={fk.tmp=29..30}] at @s run function cw:nxf/nhorse_qiiinetz