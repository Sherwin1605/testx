execute at @s as @p run function cw:nxf/ske_x2dfs6oyx
scoreboard players operation @s sk.arr = @p[tag=sk.target] clat.rslt
scoreboard players add @s sk.arr 2
tag @s add sk.rn
tag @p[tag=sk.target] remove sk.target