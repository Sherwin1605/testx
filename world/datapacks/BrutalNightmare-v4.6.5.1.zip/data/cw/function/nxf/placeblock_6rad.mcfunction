execute store result score @s posY run data get entity @s Pos[1] 1
execute store result score @p posY run data get entity @s Pos[1] 1
scoreboard players operation @s posY -= @p posY