item replace entity @s weapon.offhand with stone_axe
scoreboard players set $QQXz10YEEqU k146xYV8Q8 1