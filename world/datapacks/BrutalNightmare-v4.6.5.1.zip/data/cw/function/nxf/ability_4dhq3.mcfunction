tag @s add cw.shield
scoreboard players set $fiMrT9YQQ k146xYV8Q8 0
execute if score $fiMrT9YQQ k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_58qd
execute if score $fiMrT9YQQ k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_ngvkv
scoreboard players set $fiMrT9YQQ k146xYV8Q8 0
scoreboard players set $wsd7tM9o58 k146xYV8Q8 0
execute if score $wsd7tM9o58 k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_o5ftlioj3oh
execute if score $wsd7tM9o58 k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_5wqk
scoreboard players set $wsd7tM9o58 k146xYV8Q8 0
tag @s add specabi
scoreboard players set $DzU4z8eRn k146xYV8Q8 1