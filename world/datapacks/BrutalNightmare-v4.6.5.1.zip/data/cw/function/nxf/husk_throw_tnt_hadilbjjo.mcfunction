execute if score MinecraftVersion VersionInfo matches 3..7 run function cw:nxf/husk_3x7__kejunt0lwy
execute if score MinecraftVersion VersionInfo matches 8.. run function cw:nxf/husk_8x__bj64w1
execute as @e[type=tnt,tag=ame] at @s facing entity @p eyes positioned ~ ~1.3 ~ run function cw:nxf/husk_sjgo9eii9m