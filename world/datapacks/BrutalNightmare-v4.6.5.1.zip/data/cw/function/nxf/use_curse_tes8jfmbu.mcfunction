tellraw @a "executed!"
tag @s add blaze.us
execute at @s run tag @r[distance=..30] add blaze.tg
execute as @p[tag=blaze.tg,distance=..30] at @s run tp @s ~ ~ ~ facing entity @e[type=blaze,tag=blaze.us,limit=1,sort=nearest] feet
execute at @s facing entity @p[tag=blaze.tg,distance=..30] eyes positioned ~ ~1 ~ positioned ^ ^ ^1 run function cw:extend/_ignored_exd
effect give @p[tag=blaze.tg,distance=..30] minecraft:instant_damage 1 0
effect give @p[tag=blaze.tg,distance=..30] minecraft:wither 15 1
effect clear @p[tag=blaze.tg,distance=..30] minecraft:fire_resistance
function cw:ghasts/shoot_fireball
tag @p[tag=blaze.tg,distance=..30] remove blaze.tg
tag @s remove blaze.us