effect clear @s minecraft:levitation
tag @s remove cw.carried