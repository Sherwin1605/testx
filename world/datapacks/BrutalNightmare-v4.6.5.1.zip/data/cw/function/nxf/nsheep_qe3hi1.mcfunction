tp @s ~ ~ ~ facing entity @e[type=armor_stand,tag=fokus.sheep,limit=1,sort=nearest]
data modify entity @s NoAI set value true
tag @s add fkapi.waittg
scoreboard players operation @s fk.et.ptm = $fokusapi fk.ttm
execute as @s at @s run schedule function cw:nxf/nsheep_5ga0la83 1.5s append