replaceitem entity @s weapon.offhand ender_pearl
scoreboard players set $UGXU k146xYV8Q8 1