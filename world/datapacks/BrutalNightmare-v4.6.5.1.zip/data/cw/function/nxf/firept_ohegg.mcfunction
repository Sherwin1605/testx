effect give @s minecraft:fire_resistance 999999 1
data merge entity @s {Fire:-20}