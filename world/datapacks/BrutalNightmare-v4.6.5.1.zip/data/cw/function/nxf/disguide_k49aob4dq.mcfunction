scoreboard players set $fk.linput fokus.rrv 0
scoreboard players set $fk.uinput fokus.rrv 3
function fokus:pseudo_random
execute store result score @s cr.dsg run scoreboard players get $fk.oput fokus.rrv
execute at @s[scores={cr.dsg=0}] run function cw:creeper/disguide_sheep/disguide
execute at @s[scores={cr.dsg=1}] run function cw:creeper/disguide_cow/disguide
execute at @s[scores={cr.dsg=2}] run function cw:creeper/disguide_chicken/disguide
kill @s
execute at @s if entity @p[distance=..8] run scoreboard players set $Bmh4pb k146xYV8Q8 1