summon armor_stand ~ ~-1 ~ {Invulnerable:1b,Invisible:1b,Tags:["fokus.horse"]}
execute at @s as @e[type=armor_stand,tag=fokus.horse,sort=nearest,limit=1,distance=..5] at @s run function cw:nxf/nhorse_csmavk
kill @s