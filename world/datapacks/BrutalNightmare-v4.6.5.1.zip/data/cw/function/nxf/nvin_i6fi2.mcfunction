scoreboard players set @s vdn.noai 1
data modify entity @s NoAI set value 1b