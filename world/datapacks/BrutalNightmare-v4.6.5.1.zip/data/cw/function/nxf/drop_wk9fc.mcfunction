scoreboard players add @s ptom.dropnd 1
tp @p[tag=cw.carried,sort=nearest,limit=1] ~ ~-2 ~
effect give @p[tag=cw.carried,sort=nearest,limit=1] minecraft:levitation 2
execute as @s[scores={ptom.dropnd=100..}] at @s run function cw:nxf/drop_ryw6ix
scoreboard players set $W5pf94 k146xYV8Q8 1