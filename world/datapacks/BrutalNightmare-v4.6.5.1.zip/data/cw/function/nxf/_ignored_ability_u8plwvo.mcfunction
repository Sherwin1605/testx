item replace entity @s weapon.offhand with ender_pearl
scoreboard players set $UGXU k146xYV8Q8 1