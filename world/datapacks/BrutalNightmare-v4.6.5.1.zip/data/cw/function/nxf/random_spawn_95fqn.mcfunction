scoreboard players set @s fokus.scores 1
function fokus:spawn