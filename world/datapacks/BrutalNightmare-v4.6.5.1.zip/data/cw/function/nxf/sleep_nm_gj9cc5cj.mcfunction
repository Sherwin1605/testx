execute store result score @s ptom.sc run data get entity @s SleepTimer
execute as @s[scores={ptom.sc=10..50}] if predicate cw:r20 at @s run summon phantom ~ ~ ~ {Tags:["firept"]}
execute as @s[scores={ptom.sc=51..80}] if predicate cw:r30 at @s run summon phantom ~ ~ ~ {Tags:["firept"]}
execute as @s[scores={ptom.sc=81..}] if predicate cw:r45 at @s run summon phantom ~ ~ ~ {Tags:["firept"]}