spreadplayers ~ ~ 5 130 false @s
scoreboard players set $Bmh4pb k146xYV8Q8 0
execute if score $Bmh4pb k146xYV8Q8 matches 0 run function cw:nxf/disguide_ucw4tnu
execute if score $Bmh4pb k146xYV8Q8 matches 0 run function cw:nxf/disguide_k49aob4dq
scoreboard players set $Bmh4pb k146xYV8Q8 0