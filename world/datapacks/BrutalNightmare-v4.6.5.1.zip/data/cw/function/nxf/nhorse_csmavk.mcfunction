execute as @e[type=horse,tag=!angry_horse,distance=..7] at @s run function cw:nxf/nhorse_3ha75uxbf
kill @s