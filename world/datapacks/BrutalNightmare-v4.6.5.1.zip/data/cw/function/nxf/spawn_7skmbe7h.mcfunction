scoreboard players set $asDFl1FPcl k146xYV8Q8 0
execute if score $asDFl1FPcl k146xYV8Q8 matches 0 run function cw:nxf/_ignored_spawn_5ljlgsgx6
execute if score $asDFl1FPcl k146xYV8Q8 matches 0 run function cw:nxf/_ignored_spawn_cm6n64
scoreboard players set $asDFl1FPcl k146xYV8Q8 0
tag @s remove cw.bow