tag @s add cw.onlyme
tag @s add cw.axe_tl
scoreboard players set $QQXz10YEEqU k146xYV8Q8 0
execute if score $QQXz10YEEqU k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_vm1r3h
execute if score $QQXz10YEEqU k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_7ckb6i
scoreboard players set $QQXz10YEEqU k146xYV8Q8 0
tag @s add specabi
scoreboard players set $DzU4z8eRn k146xYV8Q8 1