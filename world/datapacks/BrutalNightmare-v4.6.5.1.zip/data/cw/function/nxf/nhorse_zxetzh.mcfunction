tag @s remove angry_horse
summon horse ~ ~ ~
function fokus:disappear