function fokus:apply_motion_slow
tag @s remove snb