scoreboard players set $fk.linput fokus.rrv 0
scoreboard players set $fk.uinput fokus.rrv 4
function fokus:real_random
execute store result score @s jk.rdum run scoreboard players get $fk.oput fokus.rrv
execute at @s[scores={jk.rdum=0}] run function cw:jockey/husk_jockey
execute at @s[scores={jk.rdum=1}] run function cw:jockey/skeleton_jockey
execute at @s[scores={jk.rdum=2}] run function cw:jockey/zoglin_jockey
execute at @s[scores={jk.rdum=3}] run function cw:jockey/skeleton_jockey_2
execute as @e[tag=cw.bow] at @s run function cw:nxf/spawn_7skmbe7h
execute as @e[tag=cw.axe] at @s run function cw:nxf/spawn_fqie
kill @s