scoreboard players set $NxdrP8ajo k146xYV8Q8 0
execute if score $NxdrP8ajo k146xYV8Q8 matches 0 if entity @p[distance=5..7] run function cw:nxf/ability_5w7g6901
execute if score $NxdrP8ajo k146xYV8Q8 matches 0 if entity @p[distance=8..18] run function cw:nxf/ability_p78gkok
scoreboard players set $NxdrP8ajo k146xYV8Q8 0