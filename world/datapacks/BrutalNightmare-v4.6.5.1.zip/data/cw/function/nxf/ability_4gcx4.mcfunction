scoreboard players set $fk.linput fokus.rrv 0
scoreboard players set $fk.uinput fokus.rrv 3
function fokus:pseudo_random
execute store result score @s sb.abil run scoreboard players get $fk.oput fokus.rrv