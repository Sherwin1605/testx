schedule function cw:nhorse/nhorse 1t
execute if score MinecraftVersion VersionInfo matches 3..10 run function cw:nxf/nhorse_3x10__7t9eo5
execute if score MinecraftVersion VersionInfo matches 11.. run function cw:nxf/nhorse_11x__s83aqwxb8wz
execute as @a at @s as @e[distance=..30,type=husk,tag=horse_psg] at @s unless entity @e[type=horse,tag=angry_horse,distance=..2] run kill @s
execute as @e[type=horse,tag=angry_horse] at @s unless entity @p[distance=..25] run function cw:nxf/nhorse_zxetzh