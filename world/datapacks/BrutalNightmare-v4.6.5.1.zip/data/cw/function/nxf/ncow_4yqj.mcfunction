scoreboard players set @s fk.et.ptm 0
scoreboard players set @s fk.tmp 0
tag @s remove fkapi.waittg
execute if score MinecraftVersion VersionInfo matches 3..7 run function cw:nxf/ncow_3x7__5srzv9m
execute if score MinecraftVersion VersionInfo matches 8..11 run function cw:nxf/ncow_8x11__vaza54s
execute if score MinecraftVersion VersionInfo matches 12.. run function cw:nxf/ncow_12x__kfba4i0nwzz
function fokus:disappear