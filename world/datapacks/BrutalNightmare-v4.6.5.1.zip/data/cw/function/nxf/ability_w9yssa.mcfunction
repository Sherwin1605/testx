function cw:zombie/shoot_edp
scoreboard players set $mp85ZYr5xKg k146xYV8Q8 1