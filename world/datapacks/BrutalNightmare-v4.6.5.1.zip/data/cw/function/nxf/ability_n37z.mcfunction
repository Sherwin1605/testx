tag @s add cw.onlyme
tag @s add cw.pickaxe_tl
scoreboard players set $PXfQpCd. k146xYV8Q8 0
execute if score $PXfQpCd. k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_1oby1c0j87x
execute if score $PXfQpCd. k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_56p6
scoreboard players set $PXfQpCd. k146xYV8Q8 0
tag @s add specabi
scoreboard players set $DzU4z8eRn k146xYV8Q8 1