tag @s remove angry_chicken
summon chicken ~ ~ ~
function fokus:disappear