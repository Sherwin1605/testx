scoreboard players set @s fk.tmp 0
scoreboard players operation @s fk.tmp += $fokusapi fk.ttm
scoreboard players operation @s fk.tmp -= @s fk.et.ptm