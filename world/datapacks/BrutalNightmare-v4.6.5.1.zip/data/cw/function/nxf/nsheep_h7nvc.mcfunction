execute as @e[type=sheep,tag=!angry_sheep,distance=..7] at @s run function cw:nxf/nsheep_qe3hi1
kill @s