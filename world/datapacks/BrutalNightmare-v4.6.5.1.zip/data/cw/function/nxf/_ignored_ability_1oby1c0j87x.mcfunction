replaceitem entity @s weapon.offhand stone_pickaxe
scoreboard players set $PXfQpCd. k146xYV8Q8 1