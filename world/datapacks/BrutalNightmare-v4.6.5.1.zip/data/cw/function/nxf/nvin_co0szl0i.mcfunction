scoreboard players set @s vdn.noai 0
data modify entity @s NoAI set value 0b