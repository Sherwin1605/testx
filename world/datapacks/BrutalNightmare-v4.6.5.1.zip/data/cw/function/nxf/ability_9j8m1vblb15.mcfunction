tag @s add cw.flint
scoreboard players set $JH2ZrWGZUlV k146xYV8Q8 0
execute if score $JH2ZrWGZUlV k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_xqlze
execute if score $JH2ZrWGZUlV k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_4xeuj1m
scoreboard players set $JH2ZrWGZUlV k146xYV8Q8 0
tag @s add specabi
scoreboard players set $DzU4z8eRn k146xYV8Q8 1