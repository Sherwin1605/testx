execute if score $rl.debug rl.debug matches 1 run tellraw @a [{"text":"Gived2"}]
function fokus:apply_motion
tag @s remove cw.fb