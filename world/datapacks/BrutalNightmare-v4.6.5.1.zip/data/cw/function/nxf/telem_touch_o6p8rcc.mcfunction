tp @p[distance=0..4] ~ ~ ~ facing entity @s feet
playsound minecraft:entity.enderman.teleport player @p[distance=0..4]