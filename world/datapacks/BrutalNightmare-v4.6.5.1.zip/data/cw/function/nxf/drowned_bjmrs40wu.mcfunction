particle minecraft:effect ~ ~1 ~ 1.5 1.5 1.5 0.07 30
tp @s ~ ~ ~