replaceitem entity @s weapon.offhand flint_and_steel
scoreboard players set $JH2ZrWGZUlV k146xYV8Q8 1