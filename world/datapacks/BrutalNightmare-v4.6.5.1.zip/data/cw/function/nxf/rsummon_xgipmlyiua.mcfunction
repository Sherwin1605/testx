scoreboard players set @s fokus.scores 7
function fokus:spawn