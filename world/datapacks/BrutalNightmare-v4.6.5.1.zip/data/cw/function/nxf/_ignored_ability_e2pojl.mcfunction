replaceitem entity @s weapon.offhand ender_pearl
scoreboard players set $PUwN2H k146xYV8Q8 1