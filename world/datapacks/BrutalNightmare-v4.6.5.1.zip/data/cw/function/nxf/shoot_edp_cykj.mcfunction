execute if score $rl.debug rl.debug matches 1 run say ME!
function fokus:apply_motion_slow
tag @s remove cw.target