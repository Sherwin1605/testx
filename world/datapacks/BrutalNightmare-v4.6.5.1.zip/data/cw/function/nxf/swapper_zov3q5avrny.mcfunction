tag @s add skeleton_swapper
scoreboard players set $WX87hMdbcn k146xYV8Q8 0
execute if score $WX87hMdbcn k146xYV8Q8 matches 0 run function cw:nxf/_ignored_swapper_jnutlbyb
execute if score $WX87hMdbcn k146xYV8Q8 matches 0 run function cw:nxf/_ignored_swapper_b8l1a49
scoreboard players set $WX87hMdbcn k146xYV8Q8 0