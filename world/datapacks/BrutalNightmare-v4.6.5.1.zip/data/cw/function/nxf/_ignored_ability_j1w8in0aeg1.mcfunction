replaceitem entity @s weapon.offhand flint_and_steel
scoreboard players set $EI7I k146xYV8Q8 1