item replace entity @s weapon.offhand with shield
scoreboard players set $fiMrT9YQQ k146xYV8Q8 1