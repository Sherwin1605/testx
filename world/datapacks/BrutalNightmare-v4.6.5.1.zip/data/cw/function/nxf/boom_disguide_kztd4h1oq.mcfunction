execute as @e[tag=disguider,distance=..3] at @s run function fokus:disappear
function fokus:disappear