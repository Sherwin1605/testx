tag @s remove skeleton_swapper
scoreboard players set $Y4hcGZH k146xYV8Q8 0
execute if score $Y4hcGZH k146xYV8Q8 matches 0 run function cw:nxf/_ignored_swapper_ftgmhavf6of
execute if score $Y4hcGZH k146xYV8Q8 matches 0 run function cw:nxf/_ignored_swapper_ef3k
scoreboard players set $Y4hcGZH k146xYV8Q8 0