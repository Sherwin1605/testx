function fokus:apply_motion_quick
tag @s remove slime.fball_fin
tag @s add slime.fball_fin_2