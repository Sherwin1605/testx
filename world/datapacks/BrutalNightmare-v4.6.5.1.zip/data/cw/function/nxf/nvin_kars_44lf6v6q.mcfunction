scoreboard players add @s vdn.count 0
tag @s add cw.nmsp
tag @s remove cw.nm
data modify entity @s NoAI set value 1b