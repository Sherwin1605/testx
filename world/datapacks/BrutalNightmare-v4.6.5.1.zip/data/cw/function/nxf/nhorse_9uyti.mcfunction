execute as @e[type=horse,tag=fkapi.waittg] run function cw:nxf/nhorse_8vz8d19s6
execute as @e[type=horse,tag=fkapi.waittg] as @s[scores={fk.tmp=29..30}] at @s run function cw:nxf/nhorse_4tk2mx2t