tag @s remove angry_cow
summon cow ~ ~ ~
function fokus:disappear