execute if score $zb.allbreaker st.activate matches 1 run function cw:nxf/ability_ww7gna
execute unless score $zb.allbreaker st.activate matches 1 run function cw:nxf/ability_gasn1rp3
scoreboard players set $KNs8.Mk k146xYV8Q8 0
execute if score $KNs8.Mk k146xYV8Q8 matches 0 as @s[scores={sb.abil=0}] run function cw:nxf/ability_5ta1pv32lz
execute if score $KNs8.Mk k146xYV8Q8 matches 0 as @s[scores={sb.abil=1}] run function cw:nxf/ability_beflvcxk8w
execute if score $KNs8.Mk k146xYV8Q8 matches 0 as @s[scores={sb.abil=2}] run function cw:nxf/ability_4awwui
execute if score $KNs8.Mk k146xYV8Q8 matches 0 as @s[scores={sb.abil=3}] run function cw:nxf/ability_731yv2nop
execute if score $KNs8.Mk k146xYV8Q8 matches 0 as @s[scores={sb.abil=4}] run function cw:nxf/ability_n8724cih6t
scoreboard players set $KNs8.Mk k146xYV8Q8 0