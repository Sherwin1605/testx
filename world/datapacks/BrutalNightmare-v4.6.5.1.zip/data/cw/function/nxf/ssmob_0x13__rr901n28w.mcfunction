scoreboard players set $eZwbwC1GS7s k146xYV8Q8 0
execute if score $eZwbwC1GS7s k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ssmob_bf5f56y
execute if score $eZwbwC1GS7s k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ssmob_n26z6ou11fq
scoreboard players set $eZwbwC1GS7s k146xYV8Q8 0