scoreboard players set $vsX6koSp5Q k146xYV8Q8 0
execute if score $vsX6koSp5Q k146xYV8Q8 matches 0 run function cw:nxf/_ignored_spawn_rnvb
execute if score $vsX6koSp5Q k146xYV8Q8 matches 0 run function cw:nxf/_ignored_spawn_k9wc8m
scoreboard players set $vsX6koSp5Q k146xYV8Q8 0
tag @s remove cw.axe