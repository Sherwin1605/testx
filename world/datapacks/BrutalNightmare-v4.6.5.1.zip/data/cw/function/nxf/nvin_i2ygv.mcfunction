scoreboard players add @s vdn.count 0
scoreboard players set @s vdn.ilook 0
scoreboard players set @s vdn.noai 1
tag @s remove cw.nmstart