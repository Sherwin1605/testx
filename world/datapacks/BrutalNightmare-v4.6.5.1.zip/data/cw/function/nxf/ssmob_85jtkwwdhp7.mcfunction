scoreboard players set $tKsomWM k146xYV8Q8 0
execute if score $tKsomWM k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ssmob_ziyyubj23v
execute if score $tKsomWM k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ssmob_44dhhmb4ag
scoreboard players set $tKsomWM k146xYV8Q8 0