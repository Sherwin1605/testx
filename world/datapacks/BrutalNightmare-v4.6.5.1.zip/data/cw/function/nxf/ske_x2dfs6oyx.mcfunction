scoreboard players set $limit clat.limit 4
function fokus:random
tag @s add sk.target