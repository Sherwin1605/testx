execute if score $rl.debug rl.debug matches 1 run tellraw @a [{"text":"Carried"}]
tag @p add cw.carried
data modify entity @s Motion set value [0.0d,0.0d,0.0d]
data modify entity @s Glowing set value 1b
tag @s add cw.ptcarry
scoreboard players set @s ptom.dropnd 0