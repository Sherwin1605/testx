scoreboard players set $MN.K k146xYV8Q8 0
execute if score $MN.K k146xYV8Q8 matches 0 run function cw:nxf/random_ho8z159tim
execute if score $MN.K k146xYV8Q8 matches 0 run function cw:nxf/random_0lwgjdy
scoreboard players set $MN.K k146xYV8Q8 0