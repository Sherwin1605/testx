tag @s add cw.nmsp
tag @s remove cw.nm
data modify entity @s NoAI set value 1b
particle minecraft:cloud ~ ~ ~ 0 0 0 0.1 20
setblock ~ ~ ~ air destroy
scoreboard players add @s vdn.dc 1