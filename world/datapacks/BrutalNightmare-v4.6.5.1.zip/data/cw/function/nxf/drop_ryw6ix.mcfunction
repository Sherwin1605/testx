execute if score $rl.debug rl.debug matches 1 run tellraw @a [{"text":"Dropped"}]
data modify entity @s Glowing set value 0b
data modify entity @s Motion set value [0.0d,0.0d,0.0d]
effect clear @p[tag=cw.carried,sort=nearest,limit=1] minecraft:levitation
tag @p remove cw.carried
tag @s remove cw.ptcarry