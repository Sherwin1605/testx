execute as @s at @s run function cw:nxf/drop_ryw6ix
scoreboard players set $W5pf94 k146xYV8Q8 1