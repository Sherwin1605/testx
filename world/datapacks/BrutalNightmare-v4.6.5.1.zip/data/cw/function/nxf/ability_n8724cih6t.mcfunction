tag @s add cw.onlyme
tag @s add cw.axe_tl
scoreboard players set $UKe55G k146xYV8Q8 0
execute if score $UKe55G k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_4yjtrkw
execute if score $UKe55G k146xYV8Q8 matches 0 run function cw:nxf/_ignored_ability_xi3qehogc5
scoreboard players set $UKe55G k146xYV8Q8 0
tag @s add specabi
scoreboard players set $KNs8.Mk k146xYV8Q8 1