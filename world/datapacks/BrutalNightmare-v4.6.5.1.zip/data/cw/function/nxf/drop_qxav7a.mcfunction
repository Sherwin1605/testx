scoreboard players set $W5pf94 k146xYV8Q8 0
execute if score $W5pf94 k146xYV8Q8 matches 0 if block ~ ~-2 ~ air run function cw:nxf/drop_wk9fc
execute if score $W5pf94 k146xYV8Q8 matches 0 if block ~ ~-2 ~ air run function cw:nxf/drop_8vxp8
scoreboard players set $W5pf94 k146xYV8Q8 0