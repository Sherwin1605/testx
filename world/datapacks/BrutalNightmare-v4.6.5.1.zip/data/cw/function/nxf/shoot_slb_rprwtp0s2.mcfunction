scoreboard players set $AfgKD2yYDn6 k146xYV8Q8 0
execute if score $AfgKD2yYDn6 k146xYV8Q8 matches 0 run function cw:nxf/_ignored_shoot_zycppt0j
execute if score $AfgKD2yYDn6 k146xYV8Q8 matches 0 run function cw:nxf/_ignored_shoot_3csnr
scoreboard players set $AfgKD2yYDn6 k146xYV8Q8 0
function fokus:apply_motion_quick
tag @s remove slime.fball
tag @s add slime.fball_fin