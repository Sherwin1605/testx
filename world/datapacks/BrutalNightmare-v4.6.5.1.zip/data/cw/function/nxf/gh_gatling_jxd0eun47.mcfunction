scoreboard players set $fk.linput fokus.rrv 2
scoreboard players set $fk.uinput fokus.rrv 6
function fokus:pseudo_random
execute store result score @s gh.fball run scoreboard players get $fk.oput fokus.rrv
tag @s add gh.rn