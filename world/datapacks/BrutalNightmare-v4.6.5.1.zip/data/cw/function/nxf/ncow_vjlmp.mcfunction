execute as @e[type=cow,tag=fkapi.waittg] run function cw:nxf/ncow_q7axv4n3
execute as @e[type=cow,tag=fkapi.waittg] as @s[scores={fk.tmp=29..30}] at @s run function cw:nxf/ncow_acaavup5k7