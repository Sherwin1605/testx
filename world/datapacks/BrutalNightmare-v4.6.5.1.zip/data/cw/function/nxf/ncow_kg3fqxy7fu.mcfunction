schedule function cw:ncow/ncow 1t
execute if score MinecraftVersion VersionInfo matches 3..10 run function cw:nxf/ncow_3x10__pmmuj
execute if score MinecraftVersion VersionInfo matches 11.. run function cw:nxf/ncow_11x__gy21k
execute as @a at @s as @e[distance=..30,type=husk,tag=cow_psg] at @s unless entity @e[type=cow,tag=angry_cow,distance=..2] run kill @s
execute as @e[type=cow,tag=angry_cow] at @s unless entity @p[distance=..25] run function cw:nxf/ncow_vfqjr8m9