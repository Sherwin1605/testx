schedule function cw:nsheep/nsheep 1t
execute if score MinecraftVersion VersionInfo matches 3..10 run function cw:nxf/nsheep_3x10__r7ikt3xtu
execute if score MinecraftVersion VersionInfo matches 11.. run function cw:nxf/nsheep_11x__2m1ha9j
execute as @a at @s as @e[distance=..30,type=husk,tag=sheep_psg] at @s unless entity @e[type=sheep,tag=angry_sheep,distance=..2] run kill @s
execute as @e[type=sheep,tag=angry_sheep] at @s unless entity @p[distance=..25] run function cw:nxf/nsheep_pm05ul2gm