execute store result score @s sl.size run data get entity @s Size 1
tag @s[scores={sl.size=3..}] add sl.us
tag @s[scores={sl.size=3..}] add sl.cs