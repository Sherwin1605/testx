scoreboard players set @s vdn.count 0
scoreboard players set @s vdn.ilook 0
scoreboard players set @s vdn.noai 1
data modify entity @s NoAI set value 1b
particle minecraft:cloud ~ ~ ~ 0 0 0 0.1 20
tag @s remove cw.nmsp
tag @s add cw.nm