function cw:drowned/curse/curse_start
scoreboard players set @s dr.dr_curse_cd 2