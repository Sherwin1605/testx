effect give @s minecraft:invisibility 999999 1 true
tag @s add cw.given