scoreboard players set @s fk.et.ptm 0
scoreboard players set @s fk.tmp 0
tag @s remove fkapi.waittg
execute if score MinecraftVersion VersionInfo matches 3..7 run function cw:nxf/nhorse_3x7__pqegkwz9yj
execute if score MinecraftVersion VersionInfo matches 8..11 run function cw:nxf/nhorse_8x11__grivpfkbg7
execute if score MinecraftVersion VersionInfo matches 12.. run function cw:nxf/nhorse_12x__w5gn3uq4uv
function fokus:disappear