execute if score $rl.debug rl.debug matches 1 run say ME!
function fokus:apply_motion
data modify entity @s NoGravity set value 0b
tag @s remove cw.target