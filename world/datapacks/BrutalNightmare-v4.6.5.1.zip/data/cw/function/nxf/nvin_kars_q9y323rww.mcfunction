execute if entity @s[scores={vdn.count=10}] run function fokus:disappear
scoreboard players add @s vdn.count 1