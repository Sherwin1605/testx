execute as @s if block ~ ~-1 ~ #minecraft:mineable/pickaxe run setblock ~ ~-1 ~ air destroy
execute as @s if block ~ ~-1 ~ #minecraft:mineable/shovel run setblock ~ ~-1 ~ air destroy
execute as @s if block ~ ~-1 ~ #minecraft:mineable/axe run setblock ~ ~-1 ~ air destroy