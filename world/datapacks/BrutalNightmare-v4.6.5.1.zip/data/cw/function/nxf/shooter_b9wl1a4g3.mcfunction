execute if score $rl.debug rl.debug matches 1 run tellraw @a [{"text":"Shoot!"}]
function cw:skeleton/shoot_arrow
scoreboard players remove @s sk.arr 1