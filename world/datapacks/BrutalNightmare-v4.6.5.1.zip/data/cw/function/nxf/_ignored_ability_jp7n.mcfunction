item replace entity @s weapon.offhand with shield
scoreboard players set $l4JhF k146xYV8Q8 1