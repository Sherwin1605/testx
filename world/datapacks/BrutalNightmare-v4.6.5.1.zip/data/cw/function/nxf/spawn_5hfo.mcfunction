scoreboard players set @s fokus.scores 4
function fokus:spawn