scoreboard players set $vXbTsBZEPF k146xYV8Q8 0
execute if score $vXbTsBZEPF k146xYV8Q8 matches 0 run function cw:nxf/_ignored_summon_hpl5g
execute if score $vXbTsBZEPF k146xYV8Q8 matches 0 run function cw:nxf/_ignored_summon_556b71
scoreboard players set $vXbTsBZEPF k146xYV8Q8 0
tag @s remove wt.crossb