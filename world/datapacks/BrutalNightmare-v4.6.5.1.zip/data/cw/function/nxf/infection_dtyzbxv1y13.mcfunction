execute if score $rl.debug rl.debug matches 1 run tellraw @a [{"text":"Happend"}]
execute at @p run tp @s ~ ~1 ~
tag @s add infector
schedule function cw:silverfish/infect_start 1s