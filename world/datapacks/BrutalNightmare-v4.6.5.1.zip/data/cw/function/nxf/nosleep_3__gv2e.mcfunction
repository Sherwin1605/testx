schedule function cw:nosleep 1t
execute as @a at @s if predicate cw:sleep run tp @s ~ ~1 ~