kill @s
scoreboard players set $fYBbX k146xYV8Q8 1