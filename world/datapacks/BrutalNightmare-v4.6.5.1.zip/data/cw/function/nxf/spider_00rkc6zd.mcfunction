scoreboard players set $X63wfR7bE k146xYV8Q8 0
execute if score $X63wfR7bE k146xYV8Q8 matches 0 run function cw:nxf/_ignored_spider_kr090u0
execute if score $X63wfR7bE k146xYV8Q8 matches 0 run function cw:nxf/_ignored_spider_ulr6pnnkh
execute if score $X63wfR7bE k146xYV8Q8 matches 0 run function cw:nxf/_ignored_spider_cyjkqe2l
execute if score $X63wfR7bE k146xYV8Q8 matches 0 run function cw:nxf/_ignored_spider_jf3yda
scoreboard players set $X63wfR7bE k146xYV8Q8 0