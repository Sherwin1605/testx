scoreboard players set $fk.linput fokus.rrv 0
scoreboard players set $fk.uinput fokus.rrv 4
function fokus:pseudo_random
execute store result score @s wt.sm run scoreboard players get $fk.oput fokus.rrv
scoreboard players set $4iGL k146xYV8Q8 0
execute if score $4iGL k146xYV8Q8 matches 0 run function cw:nxf/_ignored_summon_wdyetrgs
execute if score $4iGL k146xYV8Q8 matches 0 run function cw:nxf/_ignored_summon_c8r0ixpr8dt
scoreboard players set $4iGL k146xYV8Q8 0
execute as @e[tag=wt.bow] run function cw:nxf/summon_2oo4f2tto
execute as @e[tag=wt.axe] run function cw:nxf/summon_bvvv984
execute as @e[tag=wt.crossb] run function cw:nxf/summon_l9nsznnmae
kill @s