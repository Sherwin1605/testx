replaceitem entity @s weapon.offhand stone_pickaxe
scoreboard players set $ZbVW5mcari k146xYV8Q8 1