scoreboard players set @s fk.et.ptm 0
scoreboard players set @s fk.tmp 0
tag @s remove fkapi.waittg
tp @s ~ ~ ~ facing entity @p[gamemode=survival,scores={kill.chicken=1..},sort=nearest,limit=1]
scoreboard players set @p[gamemode=survival,scores={kill.chicken=1..},sort=nearest,limit=1] kill.chicken 0
tag @s add fkapi.waittg
scoreboard players operation @s fk.et.ptm = $fokusapi fk.ttm
execute as @s at @s run schedule function cw:nxf/nchicken_wsohyzjxfe0 1.5s append