function cw:husk/shoot_edp_strong
scoreboard players set $NxdrP8ajo k146xYV8Q8 1