execute as @a[scores={em.edm_curse=2..}] run scoreboard players remove @s em.edm_curse 1
execute as @a[scores={em.edm_curse=11}] at @s run particle minecraft:dragon_breath ~ ~2 ~ 1.5 2 1.5 0.07 30 normal
execute as @a[scores={em.edm_curse=8}] at @s run particle minecraft:dragon_breath ~ ~2 ~ 1.5 2 1.5 0.07 30 normal
execute as @a[scores={em.edm_curse=16}] at @s run playsound minecraft:block.portal.travel block @s ~ ~ ~ 10000 .1
execute as @a[scores={em.edm_curse=30}] at @s run playsound minecraft:entity.iron_golem.step record @s ~ ~ ~ 60000 0.00005
execute as @a[scores={em.edm_curse=29}] at @s run playsound minecraft:entity.iron_golem.step record @s ~ ~ ~ 80000 0.00005
execute as @a[scores={em.edm_curse=28}] at @s run playsound minecraft:entity.iron_golem.step record @s ~ ~ ~ 100000 0.00005
execute as @a[scores={em.edm_curse=14..27}] at @s run playsound minecraft:entity.iron_golem.step record @s ~ ~ ~ 100000 0.00005
execute as @a[scores={em.edm_curse=20}] at @s run playsound minecraft:entity.iron_golem.step record @s ~ ~ ~ 80000 0.00005