execute positioned ~ ~ ~ run function cw:nxf/extend_6qo3mcem
kill @s