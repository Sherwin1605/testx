tp @s ~ ~ ~ facing entity @p eyes
summon snowball ~ ~3.2 ~ {Tags:["snb"]}
execute at @s positioned ~ ~3.2 ~ rotated as @s as @e[type=snowball,tag=snb] run function cw:nxf/shoot_snowball_ruo4txn3