schedule function cw:extend/extend 1.5s
execute as @e[tag=witcher] at @s positioned ~ ~-1.5 ~ run function cw:extend/_ignored_1
execute as @e[tag=witcher] at @s positioned ~ ~-2 ~ run scoreboard players add @a[distance=0..5] mw.burn 1
execute as @a[scores={mw.burn=16}] run effect give @s instant_damage 1 0
execute as @a[scores={mw.burn=16}] run scoreboard players set @s mw.burn 0
execute as @e[tag=witcher] at @s unless entity @e[type=witch,tag=witcher_passenger] run function cw:extend/_ignored_5
execute as @e[tag=witcher] at @s unless entity @e[type=witch,tag=witcher_passenger] run function cw:nxf/extend_ysywsivy0