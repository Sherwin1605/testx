schedule function cw:illusioner/randomspawn 60s
execute as @r[limit=7] at @s if predicate cw:r20 run function cw:nxf/randomspawn_myvq