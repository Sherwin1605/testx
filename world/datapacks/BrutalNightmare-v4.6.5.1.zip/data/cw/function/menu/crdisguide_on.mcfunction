tellraw @a "[MENU] Menu Activated"
scoreboard players set $cr.disguide st.success 1
scoreboard players set $cr.disguide st.activate 1
function cw:creeper/disguide_summon
function cw:creeper/end_disguide
function cw:creeper/boom_disguide