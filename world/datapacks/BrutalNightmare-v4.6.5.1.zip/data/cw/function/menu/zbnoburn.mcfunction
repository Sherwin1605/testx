scoreboard players set $zb.noburn st.success 0
execute as @s if score $zb.noburn st.success matches 0 if score $zb.noburn st.activate matches 1 run function cw:menu/zbnoburn_off
execute as @s if score $zb.noburn st.success matches 0 unless score $zb.noburn st.activate matches 1 run function cw:menu/zbnoburn_on
scoreboard players set $zb.noburn st.success 0
function cw:menu/main