tellraw @a "[MENU] Menu Activated"
scoreboard players set $bl.spawnao st.success 1
scoreboard players set $bl.spawnao st.activate 1
function cw:blaze/spawn