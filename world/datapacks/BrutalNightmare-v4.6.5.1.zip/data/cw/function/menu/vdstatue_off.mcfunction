tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $vd.statue st.success 1
scoreboard players set $vd.statue st.activate 0
schedule clear cw:vindicator/nvin_kars
schedule clear cw:vindicator/nvin
schedule clear cw:vindicator/nvin_summon