scoreboard players set $wm.rsum st.success 0
execute as @s if score $wm.rsum st.success matches 0 if score $wm.rsum st.activate matches 1 run function cw:menu/wmrsum_off
execute as @s if score $wm.rsum st.success matches 0 unless score $wm.rsum st.activate matches 1 run function cw:menu/wmrsum_on
scoreboard players set $wm.rsum st.success 0
function cw:menu/main