tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $mob.inv st.success 1
scoreboard players set $mob.inv st.activate 0
schedule clear cw:invisiblem