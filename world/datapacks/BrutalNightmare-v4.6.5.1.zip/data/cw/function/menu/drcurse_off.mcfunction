tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $dr.curse st.success 1
scoreboard players set $dr.curse st.activate 0
schedule clear cw:drowned/curse/tick
schedule clear cw:drowned/curse/tick
schedule clear cw:drowned/curse/_real_countdown
schedule clear cw:drowned/curse/_real_on
schedule clear cw:drowned/curse/_real_start