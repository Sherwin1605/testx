tellraw @a "[MENU] Menu Activated"
scoreboard players set $bl.caskill st.success 1
scoreboard players set $bl.caskill st.activate 1
function cw:blaze/doubler