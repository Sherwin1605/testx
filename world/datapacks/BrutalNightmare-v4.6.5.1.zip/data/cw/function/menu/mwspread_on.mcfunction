tellraw @a "[MENU] Menu Activated"
scoreboard players set $mw.spread st.success 1
scoreboard players set $mw.spread st.activate 1
function cw:mwitch/spread