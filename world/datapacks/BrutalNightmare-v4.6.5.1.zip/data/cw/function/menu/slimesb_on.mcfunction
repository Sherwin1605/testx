tellraw @a "[MENU] Menu Activated"
scoreboard players set $slime.sb st.success 1
scoreboard players set $slime.sb st.activate 1
function cw:slime/ddamage
function cw:slime/loop