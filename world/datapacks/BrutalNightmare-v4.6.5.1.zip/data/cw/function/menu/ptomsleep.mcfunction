scoreboard players set $ptom.sleep st.success 0
execute as @s if score $ptom.sleep st.success matches 0 if score $ptom.sleep st.activate matches 1 run function cw:menu/ptomsleep_off
execute as @s if score $ptom.sleep st.success matches 0 unless score $ptom.sleep st.activate matches 1 run function cw:menu/ptomsleep_on
scoreboard players set $ptom.sleep st.success 0
function cw:menu/main