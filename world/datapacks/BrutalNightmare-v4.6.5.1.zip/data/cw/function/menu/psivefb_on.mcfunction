tellraw @a "[MENU] Menu Activated"
scoreboard players set $psive.fb st.success 1
scoreboard players set $psive.fb st.activate 1