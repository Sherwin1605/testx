tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $cr.sap st.success 1
scoreboard players set $cr.sap st.activate 0
schedule clear cw:creeper/random_summon