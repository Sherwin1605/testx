tellraw @a "[MENU] Menu Activated"
scoreboard players set $zb.bblock st.success 1
scoreboard players set $zb.bblock st.activate 1
function cw:zombie/breakblock
function cw:husk/breakblock
function cw:zombie/placeblock_under
function cw:husk/placeblock_under