tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $cr.ssnow st.success 1
scoreboard players set $cr.ssnow st.activate 0
schedule clear cw:creeper/creeper_shoot_snowball