tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $zb.ttnt st.success 1
scoreboard players set $zb.ttnt st.activate 0
schedule clear cw:zombie/zombie_throw_tnt
schedule clear cw:husk/husk_throw_tnt