scoreboard players set $zb.bblock st.success 0
execute as @s if score $zb.bblock st.success matches 0 if score $zb.bblock st.activate matches 1 run function cw:menu/zbbblock_off
execute as @s if score $zb.bblock st.success matches 0 unless score $zb.bblock st.activate matches 1 run function cw:menu/zbbblock_on
scoreboard players set $zb.bblock st.success 0
function cw:menu/main