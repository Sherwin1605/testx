scoreboard players set $bl.caskill st.success 0
execute as @s if score $bl.caskill st.success matches 0 if score $bl.caskill st.activate matches 1 run function cw:menu/blcaskill_off
execute as @s if score $bl.caskill st.success matches 0 unless score $bl.caskill st.activate matches 1 run function cw:menu/blcaskill_on
scoreboard players set $bl.caskill st.success 0
function cw:menu/main