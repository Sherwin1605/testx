tellraw @a "[MENU] Menu Activated"
scoreboard players set $dashforward st.success 1
scoreboard players set $dashforward st.activate 1
function cw:hardattrb/dashforward