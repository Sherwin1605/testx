scoreboard players set $mw.freeze st.success 0
execute as @s if score $mw.freeze st.success matches 0 if score $mw.freeze st.activate matches 1 run function cw:menu/mwfreeze_off
execute as @s if score $mw.freeze st.success matches 0 unless score $mw.freeze st.activate matches 1 run function cw:menu/mwfreeze_on
scoreboard players set $mw.freeze st.success 0
function cw:menu/main