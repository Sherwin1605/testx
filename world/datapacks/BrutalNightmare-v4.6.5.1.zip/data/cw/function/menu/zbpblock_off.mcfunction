tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $zb.pblock st.success 1
scoreboard players set $zb.pblock st.activate 0
schedule clear cw:zombie/placeblock
execute unless score $zb.bblock st.activate matches 1 run schedule clear cw:zombie/placeblock_under
schedule clear cw:husk/placeblock
execute unless score $zb.bblock st.activate matches 1 run schedule clear cw:husk/placeblock_under