scoreboard players set $hardattrb st.success 0
execute as @s if score $hardattrb st.success matches 0 if score $hardattrb st.activate matches 1 run function cw:menu/hardattrb_off
execute as @s if score $hardattrb st.success matches 0 unless score $hardattrb st.activate matches 1 run function cw:menu/hardattrb_on
scoreboard players set $hardattrb st.success 0
function cw:menu/main