tellraw @a "[MENU] Menu Activated"
scoreboard players set $ilu.rsum st.success 1
scoreboard players set $ilu.rsum st.activate 1
function cw:illusioner/randomspawn