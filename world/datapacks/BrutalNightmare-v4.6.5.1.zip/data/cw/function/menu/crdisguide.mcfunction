scoreboard players set $cr.disguide st.success 0
execute as @s if score $cr.disguide st.success matches 0 if score $cr.disguide st.activate matches 1 run function cw:menu/crdisguide_off
execute as @s if score $cr.disguide st.success matches 0 unless score $cr.disguide st.activate matches 1 run function cw:menu/crdisguide_on
scoreboard players set $cr.disguide st.success 0
function cw:menu/main