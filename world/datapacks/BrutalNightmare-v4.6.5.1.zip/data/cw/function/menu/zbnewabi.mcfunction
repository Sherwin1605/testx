scoreboard players set $zb.newabi st.success 0
execute as @s if score $zb.newabi st.success matches 0 if score $zb.newabi st.activate matches 1 run function cw:menu/zbnewabi_off
execute as @s if score $zb.newabi st.success matches 0 unless score $zb.newabi st.activate matches 1 run function cw:menu/zbnewabi_on
scoreboard players set $zb.newabi st.success 0
function cw:menu/main