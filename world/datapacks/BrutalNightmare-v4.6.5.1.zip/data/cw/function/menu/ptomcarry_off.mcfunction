tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $ptom.carry st.success 1
scoreboard players set $ptom.carry st.activate 0
schedule clear cw:phantom/carry
schedule clear cw:phantom/drop