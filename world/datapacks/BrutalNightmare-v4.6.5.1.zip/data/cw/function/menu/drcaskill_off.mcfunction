tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $dr.caskill st.success 1
scoreboard players set $dr.caskill st.activate 0
schedule clear cw:drowned/drowned