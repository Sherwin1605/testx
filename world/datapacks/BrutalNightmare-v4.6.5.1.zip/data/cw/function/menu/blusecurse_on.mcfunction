tellraw @a "[MENU] Menu Activated"
scoreboard players set $bl.usecurse st.success 1
scoreboard players set $bl.usecurse st.activate 1
function cw:blaze/use_curse