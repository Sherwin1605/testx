tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $zb.smoften st.success 1
scoreboard players set $zb.smoften st.activate 0
schedule clear cw:zombie/random_spawn