tellraw @a "[MENU] Menu Activated"
scoreboard players set $dr.caskill st.success 1
scoreboard players set $dr.caskill st.activate 1
function cw:drowned/drowned