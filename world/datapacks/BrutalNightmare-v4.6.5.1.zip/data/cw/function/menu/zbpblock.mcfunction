scoreboard players set $zb.pblock st.success 0
execute as @s if score $zb.pblock st.success matches 0 if score $zb.pblock st.activate matches 1 run function cw:menu/zbpblock_off
execute as @s if score $zb.pblock st.success matches 0 unless score $zb.pblock st.activate matches 1 run function cw:menu/zbpblock_on
scoreboard players set $zb.pblock st.success 0
function cw:menu/main