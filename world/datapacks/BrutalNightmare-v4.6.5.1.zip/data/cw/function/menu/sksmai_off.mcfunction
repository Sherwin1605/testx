tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $sk.smai st.success 1
scoreboard players set $sk.smai st.activate 0
schedule clear cw:skeleton/swapper