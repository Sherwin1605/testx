scoreboard players set $sk.noburn st.success 0
execute as @s if score $sk.noburn st.success matches 0 if score $sk.noburn st.activate matches 1 run function cw:menu/sknoburn_off
execute as @s if score $sk.noburn st.success matches 0 unless score $sk.noburn st.activate matches 1 run function cw:menu/sknoburn_on
scoreboard players set $sk.noburn st.success 0
function cw:menu/main