tellraw @a "[MENU] Menu Activated"
scoreboard players set $sfish.ife st.success 1
scoreboard players set $sfish.ife st.activate 1
function cw:silverfish/infection
function cw:silverfish/infect_loop