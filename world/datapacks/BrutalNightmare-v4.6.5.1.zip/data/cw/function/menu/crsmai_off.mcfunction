tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $cr.smai st.success 1
scoreboard players set $cr.smai st.activate 0
schedule clear cw:screeper