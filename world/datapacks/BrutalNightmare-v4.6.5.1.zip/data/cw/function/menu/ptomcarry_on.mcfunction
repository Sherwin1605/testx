tellraw @a "[MENU] Menu Activated"
scoreboard players set $ptom.carry st.success 1
scoreboard players set $ptom.carry st.activate 1
function cw:phantom/carry
function cw:phantom/drop