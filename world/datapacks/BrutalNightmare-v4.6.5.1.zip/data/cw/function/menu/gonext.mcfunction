execute if score $cw.fs cw.menu.page matches 1..9 run scoreboard players add $cw.fs cw.menu.page 1
function cw:menu/main