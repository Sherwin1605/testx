tellraw @a "[MENU] Menu Activated"
scoreboard players set $sk.gattshot st.success 1
scoreboard players set $sk.gattshot st.activate 1
function cw:skeleton/ske_gatling
function cw:skeleton/shooter