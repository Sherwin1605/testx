tellraw @a "[MENU] Menu Activated"
scoreboard players set $cr.sap st.success 1
scoreboard players set $cr.sap st.activate 1
function cw:creeper/random_summon