scoreboard players set $cr.ssnow st.success 0
execute as @s if score $cr.ssnow st.success matches 0 if score $cr.ssnow st.activate matches 1 run function cw:menu/crssnow_off
execute as @s if score $cr.ssnow st.success matches 0 unless score $cr.ssnow st.activate matches 1 run function cw:menu/crssnow_on
scoreboard players set $cr.ssnow st.success 0
function cw:menu/main