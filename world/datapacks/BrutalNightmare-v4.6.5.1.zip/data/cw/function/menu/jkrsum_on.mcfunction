tellraw @a "[MENU] Menu Activated"
scoreboard players set $jk.rsum st.success 1
scoreboard players set $jk.rsum st.activate 1
function cw:jockey/spawn
function cw:jockey/jockey_speed