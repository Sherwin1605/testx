tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $zb.noburn st.success 1
scoreboard players set $zb.noburn st.activate 0
schedule clear cw:zombie/ssmob