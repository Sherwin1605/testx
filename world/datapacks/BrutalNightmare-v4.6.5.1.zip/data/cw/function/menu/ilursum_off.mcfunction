tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $ilu.rsum st.success 1
scoreboard players set $ilu.rsum st.activate 0
schedule clear cw:illusioner/randomspawn