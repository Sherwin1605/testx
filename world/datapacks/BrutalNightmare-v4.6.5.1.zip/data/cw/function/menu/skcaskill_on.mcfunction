tellraw @a "[MENU] Menu Activated"
scoreboard players set $sk.caskill st.success 1
scoreboard players set $sk.caskill st.activate 1
function cw:skeleton/skeleton