scoreboard players set $zb.ttnt st.success 0
execute as @s if score $zb.ttnt st.success matches 0 if score $zb.ttnt st.activate matches 1 run function cw:menu/zbttnt_off
execute as @s if score $zb.ttnt st.success matches 0 unless score $zb.ttnt st.activate matches 1 run function cw:menu/zbttnt_on
scoreboard players set $zb.ttnt st.success 0
function cw:menu/main