tellraw @a "[MENU] Menu Activated"
scoreboard players set $zb.smoften st.success 1
scoreboard players set $zb.smoften st.activate 1
function cw:zombie/random_spawn