scoreboard players set $mob.inv st.success 0
execute as @s if score $mob.inv st.success matches 0 if score $mob.inv st.activate matches 1 run function cw:menu/mobinv_off
execute as @s if score $mob.inv st.success matches 0 unless score $mob.inv st.activate matches 1 run function cw:menu/mobinv_on
scoreboard players set $mob.inv st.success 0
function cw:menu/main