scoreboard players set $sk.smai st.success 0
execute as @s if score $sk.smai st.success matches 0 if score $sk.smai st.activate matches 1 run function cw:menu/sksmai_off
execute as @s if score $sk.smai st.success matches 0 unless score $sk.smai st.activate matches 1 run function cw:menu/sksmai_on
scoreboard players set $sk.smai st.success 0
function cw:menu/main