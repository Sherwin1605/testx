scoreboard players set $sk.gattshot st.success 0
execute as @s if score $sk.gattshot st.success matches 0 if score $sk.gattshot st.activate matches 1 run function cw:menu/skgattshot_off
execute as @s if score $sk.gattshot st.success matches 0 unless score $sk.gattshot st.activate matches 1 run function cw:menu/skgattshot_on
scoreboard players set $sk.gattshot st.success 0
function cw:menu/main