tellraw @a "[MENU] Menu Activated"
scoreboard players set $cr.smai st.success 1
scoreboard players set $cr.smai st.activate 1
function cw:screeper