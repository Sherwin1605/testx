tellraw @a "[MENU] Menu Activated"
scoreboard players set $ptom.rsum st.success 1
scoreboard players set $ptom.rsum st.activate 1
function cw:phantom/rsummon
function cw:phantom/firept