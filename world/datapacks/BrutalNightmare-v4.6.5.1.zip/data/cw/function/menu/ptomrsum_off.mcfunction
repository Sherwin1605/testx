tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $ptom.rsum st.success 1
scoreboard players set $ptom.rsum st.activate 0
schedule clear cw:phantom/rsummon
schedule clear cw:phantom/firept