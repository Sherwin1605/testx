scoreboard players set $mw.burning st.success 0
execute as @s if score $mw.burning st.success matches 0 if score $mw.burning st.activate matches 1 run function cw:menu/mwburning_off
execute as @s if score $mw.burning st.success matches 0 unless score $mw.burning st.activate matches 1 run function cw:menu/mwburning_on
scoreboard players set $mw.burning st.success 0
function cw:menu/main