tellraw @a "[MENU] Menu Activated"
scoreboard players set $zb.pblock st.success 1
scoreboard players set $zb.pblock st.activate 1
function cw:zombie/placeblock
function cw:zombie/placeblock_under
function cw:husk/placeblock
function cw:husk/placeblock_under