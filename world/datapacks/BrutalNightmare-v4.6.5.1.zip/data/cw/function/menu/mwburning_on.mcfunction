tellraw @a "[MENU] Menu Activated"
scoreboard players set $mw.burning st.success 1
scoreboard players set $mw.burning st.activate 1
function cw:mwitch/burning