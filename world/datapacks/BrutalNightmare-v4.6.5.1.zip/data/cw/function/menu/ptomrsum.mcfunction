scoreboard players set $ptom.rsum st.success 0
execute as @s if score $ptom.rsum st.success matches 0 if score $ptom.rsum st.activate matches 1 run function cw:menu/ptomrsum_off
execute as @s if score $ptom.rsum st.success matches 0 unless score $ptom.rsum st.activate matches 1 run function cw:menu/ptomrsum_on
scoreboard players set $ptom.rsum st.success 0
function cw:menu/main