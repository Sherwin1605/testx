tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $cr.disguide st.success 1
scoreboard players set $cr.disguide st.activate 0
schedule clear cw:creeper/disguide_summon
schedule clear cw:creeper/end_disguide
schedule clear cw:creeper/boom_disguide