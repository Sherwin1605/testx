tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $slime.sb st.success 1
scoreboard players set $slime.sb st.activate 0
schedule clear cw:slime/ddamage
schedule clear cw:slime/loop