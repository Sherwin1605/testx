scoreboard players set $mw.drop st.success 0
execute as @s if score $mw.drop st.success matches 0 if score $mw.drop st.activate matches 1 run function cw:menu/mwdrop_off
execute as @s if score $mw.drop st.success matches 0 unless score $mw.drop st.activate matches 1 run function cw:menu/mwdrop_on
scoreboard players set $mw.drop st.success 0
function cw:menu/main