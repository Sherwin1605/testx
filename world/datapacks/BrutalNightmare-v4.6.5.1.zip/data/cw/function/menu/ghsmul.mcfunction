scoreboard players set $gh.smul st.success 0
execute as @s if score $gh.smul st.success matches 0 if score $gh.smul st.activate matches 1 run function cw:menu/ghsmul_off
execute as @s if score $gh.smul st.success matches 0 unless score $gh.smul st.activate matches 1 run function cw:menu/ghsmul_on
scoreboard players set $gh.smul st.success 0
function cw:menu/main