scoreboard players set $nosleep st.success 0
execute as @s if score $nosleep st.success matches 0 if score $nosleep st.activate matches 1 run function cw:menu/nosleep_off
execute as @s if score $nosleep st.success matches 0 unless score $nosleep st.activate matches 1 run function cw:menu/nosleep_on
scoreboard players set $nosleep st.success 0
function cw:menu/main