tellraw @a "[MENU] Menu Activated"
scoreboard players set $nosleep st.success 1
scoreboard players set $nosleep st.activate 1
function cw:nosleep