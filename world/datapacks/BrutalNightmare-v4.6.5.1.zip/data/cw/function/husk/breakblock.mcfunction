schedule function cw:husk/breakblock 5s
execute if score $zb.allbreaker st.activate matches 1 run function cw:nxf/breakblock_ceoxq
execute unless score $zb.allbreaker st.activate matches 1 run function cw:nxf/breakblock_t7v2