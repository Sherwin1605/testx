schedule function cw:husk/random_spawn 25s
execute as @r[limit=7] at @s if predicate cw:r30 run function cw:nxf/random_spawn_bp8s48ih