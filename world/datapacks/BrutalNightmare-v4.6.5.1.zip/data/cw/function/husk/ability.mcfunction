schedule function cw:husk/ability 6s
execute as @r[gamemode=survival,limit=10] at @s as @e[type=husk,distance=..7,tag=!specabi,limit=3,tag=!exc] at @s if predicate cw:r30 run function cw:nxf/ability_s1kgt
execute as @a[gamemode=survival] at @s as @e[type=husk,distance=..7,tag=cw.flint] at @s if predicate cw:r20 run function cw:nxf/ability_1qisgl4abws
execute as @a[gamemode=survival] at @s as @e[type=husk,distance=5..18,tag=cw.enderp] at @s if block ~ ~1 ~ air if predicate cw:r30 run function cw:nxf/ability_90be4hj2