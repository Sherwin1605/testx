schedule function cw:husk/placeblock 0.5s
execute as @a[gamemode=survival] at @s as @e[type=husk,distance=..10,tag=!exc] at @s run function cw:husk/check_path_2
execute as @a[gamemode=survival] at @s as @e[type=husk,distance=..10,tag=!exc,scores={gl.pathAv=0}] at @s positioned ~ ~-1 ~ facing entity @p eyes run setblock ^ ^ ^1 dirt