summon minecraft:ender_pearl ~ ~3 ~ {Tags:["cw.target"],NoGravity:1b}
data modify entity @e[type=ender_pearl,tag=cw.target,limit=1] Owner set from entity @s UUID
execute as @e[type=ender_pearl,tag=cw.target] at @s facing entity @p eyes rotated ~ ~-50 run function cw:nxf/shoot_edp_v087dms8626