summon lightning_bolt ~ ~ ~
summon blaze ~ ~ ~ {Tags:["doubler"]}
summon blaze ~ ~ ~ {Tags:["doubler"]}
function fokus:disappear