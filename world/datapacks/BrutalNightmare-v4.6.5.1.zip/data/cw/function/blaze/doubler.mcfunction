schedule function cw:blaze/doubler 1s
scoreboard players set $zayJ6ye k146xYV8Q8 0
execute if score $zayJ6ye k146xYV8Q8 matches 0 run function cw:nxf/_ignored_doubler_3xvpkzr
execute if score $zayJ6ye k146xYV8Q8 matches 0 run function cw:nxf/_ignored_doubler_ae4ygclcxam
scoreboard players set $zayJ6ye k146xYV8Q8 0
execute as @a at @s run function cw:nxf/doubler_2oam2w0g90