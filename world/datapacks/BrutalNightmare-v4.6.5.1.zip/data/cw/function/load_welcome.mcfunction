scoreboard players set $cw.wc cw.fl 0
execute if score $fokus.rn islib matches 1 run function cw:nxf/load_welcome_15hy
execute if score $reactify.rn islib matches 1 run function cw:nxf/load_welcome_pkc4a
execute if score $cw.wc cw.fl matches 1 run tellraw @a [{"text":"[BrutalNightmare] Open settings with /function cw:menu/main.","bold":true,"color":"green"}]
execute unless score $cw.wc cw.fl matches 1 run schedule function cw:load_welcome 5s