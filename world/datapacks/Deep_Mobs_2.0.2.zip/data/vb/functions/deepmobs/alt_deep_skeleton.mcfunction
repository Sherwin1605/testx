# Skeleton Alt
execute as @s at @s run summon minecraft:wither_skeleton ~ ~ ~
data merge entity @s {Silent:1b, DeathLootTable:"minecraft:empty", NoAI:1b, Tags:["deepmobs.set"]}
teleport @s ~ -70 ~
kill @s