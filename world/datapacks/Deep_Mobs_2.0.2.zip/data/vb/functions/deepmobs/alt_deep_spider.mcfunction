# Spider Alt
execute as @s at @s run summon minecraft:cave_spider ~ ~ ~
data merge entity @s {Silent:1b, DeathLootTable:"minecraft:empty", NoAI:1b, Tags:["deepmobs.set"]}
teleport @s ~ -70 ~
kill @s