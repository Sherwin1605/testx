# Change Deep Mobs
# Alts
execute as @e[type=skeleton,predicate=vb:deepmobs/in_deep,predicate=vb:deepmobs/20_percent,tag=!deepmobs.set] at @s if block ~ ~2 ~ #vb:air run function vb:deepmobs/alt_deep_skeleton
execute as @e[type=spider,predicate=vb:deepmobs/in_deep,predicate=vb:deepmobs/20_percent,tag=!deepmobs.set] at @s run function vb:deepmobs/alt_deep_spider
# Regular
execute as @e[type=zombie,predicate=vb:deepmobs/in_deep,tag=!deepmobs.set] at @s run data merge entity @s {Attributes: [{Base: 4.0d, Name: "generic.armor"},{Base: 5.0d, Name: "generic.attack_damage"},{Base: 40.0d, Name: "generic.max_health"},{Base: 30.0d, Name: "generic.follow_range"}], Health: 40.0f, Tags:["deepmobs.set"]}
execute as @e[type=skeleton,predicate=vb:deepmobs/in_deep,tag=!deepmobs.set] at @s run data merge entity @s {Attributes: [{Base: 2.0d, Name: "generic.armor"},{Base: 3.0d, Name: "generic.attack_damage"},{Base: 25.0d, Name: "generic.max_health"},{Base: 20.0d, Name: "generic.follow_range"}], Health: 25.0f, Tags:["deepmobs.set"]}
execute as @e[type=creeper,predicate=vb:deepmobs/in_deep,tag=!deepmobs.set] at @s run data merge entity @s {Attributes: [{Base: 2.0d, Name: "generic.armor"},{Base: 25.0d, Name: "generic.max_health"},{Base: 20.0d, Name: "generic.follow_range"}], Health: 25.0f, ExplosionRadius: 4b, Fuse: 20s, Tags:["deepmobs.set"]}
execute as @e[type=spider,predicate=vb:deepmobs/in_deep,tag=!deepmobs.set] at @s run data merge entity @s {Attributes: [{Base: 2.0d, Name: "generic.armor"},{Base: 3.0d, Name: "generic.attack_damage"},{Base: 20.0d, Name: "generic.max_health"},{Base: 20.0d, Name: "generic.follow_range"},{Base: 0.4, Name: "generic.movement_speed"}], Health: 20.0f, Tags:["deepmobs.set"]}

# Tag Non-Deep Mobs
execute as @e[type=#vb:targeted_mobs,predicate=vb:deepmobs/not_in_deep,tag=!deepmobs.set] run tag @s add deepmobs.set

# Loop
schedule function vb:deepmobs/deep_mobs 1s