scoreboard players set blockanims refresh_settings 0




function vanilla_refresh:other/menus/block/settings1

playsound entity.experience_orb.pickup player @s ~ ~ ~ 1 1