scoreboard players set command_block refresh_settings 0




function vanilla_refresh:other/menus/block/settings5

playsound entity.experience_orb.pickup player @s ~ ~ ~ 1 1